﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace FUTAS.DataAccess
{
    class ConnectData
    {
        private SqlConnection conn;
        private SqlDataAdapter dataAp;
        private DataTable dataTable;

        //Constructor
        public ConnectData() 
        {
            Connect();
        }
        //ket noi
        public void Connect ()
        {
            string strConn = @"Data Source=DELL-PC;Initial Catalog=dbFUTASv2;Integrated Security=True";
            try 
            {
                conn = new SqlConnection(strConn);
                conn.Open();
                conn.Close();
            }
            catch(SqlException ex)
            {
                MessageBox.Show("Error: "+ex.Message);
            }
        }


    }
}
