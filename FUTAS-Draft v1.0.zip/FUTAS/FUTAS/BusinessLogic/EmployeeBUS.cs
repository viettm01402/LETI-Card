﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using FUTAS.DataAccess;

namespace FUTAS.BusinessLogic
{
	class EmployeeBUS
	{
        ConnectData connData = new ConnectData();

        public DataTable GetListEmployee() 
        {
            string sql = "SELECT  EmpID, EmpName, DOB, Gender, CardID, GroupID, JoinDate, BaseSalary FROM tblEmployee";
            return connData.GetDataTable(sql);

        }
	}
}
