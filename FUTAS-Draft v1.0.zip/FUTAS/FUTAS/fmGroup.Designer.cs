﻿namespace FUTAS
{
    partial class fmGroup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvShift = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbGroupName = new System.Windows.Forms.TextBox();
            this.tbDepName = new System.Windows.Forms.TextBox();
            this.tbGroupID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btThemGr = new System.Windows.Forms.Button();
            this.btSuaGr = new System.Windows.Forms.Button();
            this.btCancelGr = new System.Windows.Forms.Button();
            this.btSaveGr = new System.Windows.Forms.Button();
            this.btXoaGr = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvShift)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvShift
            // 
            this.dgvShift.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvShift.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvShift.Location = new System.Drawing.Point(0, 163);
            this.dgvShift.Name = "dgvShift";
            this.dgvShift.Size = new System.Drawing.Size(837, 285);
            this.dgvShift.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier New", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(293, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "Quản lý phòng ban";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(313, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tên Nhóm";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(569, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Bộ Phận";
            // 
            // tbGroupName
            // 
            this.tbGroupName.Location = new System.Drawing.Point(376, 59);
            this.tbGroupName.Name = "tbGroupName";
            this.tbGroupName.Size = new System.Drawing.Size(155, 20);
            this.tbGroupName.TabIndex = 5;
            // 
            // tbDepName
            // 
            this.tbDepName.Location = new System.Drawing.Point(623, 59);
            this.tbDepName.Name = "tbDepName";
            this.tbDepName.Size = new System.Drawing.Size(155, 20);
            this.tbDepName.TabIndex = 6;
            // 
            // tbGroupID
            // 
            this.tbGroupID.Location = new System.Drawing.Point(123, 59);
            this.tbGroupID.Name = "tbGroupID";
            this.tbGroupID.Size = new System.Drawing.Size(155, 20);
            this.tbGroupID.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(60, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Mã Nhóm";
            // 
            // btThemGr
            // 
            this.btThemGr.Location = new System.Drawing.Point(63, 109);
            this.btThemGr.Name = "btThemGr";
            this.btThemGr.Size = new System.Drawing.Size(87, 37);
            this.btThemGr.TabIndex = 9;
            this.btThemGr.Text = "Thêm";
            this.btThemGr.UseVisualStyleBackColor = true;
            // 
            // btSuaGr
            // 
            this.btSuaGr.Location = new System.Drawing.Point(216, 109);
            this.btSuaGr.Name = "btSuaGr";
            this.btSuaGr.Size = new System.Drawing.Size(87, 37);
            this.btSuaGr.TabIndex = 10;
            this.btSuaGr.Text = "Sửa";
            this.btSuaGr.UseVisualStyleBackColor = true;
            // 
            // btCancelGr
            // 
            this.btCancelGr.Location = new System.Drawing.Point(691, 109);
            this.btCancelGr.Name = "btCancelGr";
            this.btCancelGr.Size = new System.Drawing.Size(87, 37);
            this.btCancelGr.TabIndex = 11;
            this.btCancelGr.Text = "Hủy";
            this.btCancelGr.UseVisualStyleBackColor = true;
            // 
            // btSaveGr
            // 
            this.btSaveGr.Location = new System.Drawing.Point(540, 109);
            this.btSaveGr.Name = "btSaveGr";
            this.btSaveGr.Size = new System.Drawing.Size(87, 37);
            this.btSaveGr.TabIndex = 12;
            this.btSaveGr.Text = "Lưu";
            this.btSaveGr.UseVisualStyleBackColor = true;
            // 
            // btXoaGr
            // 
            this.btXoaGr.Location = new System.Drawing.Point(376, 109);
            this.btXoaGr.Name = "btXoaGr";
            this.btXoaGr.Size = new System.Drawing.Size(87, 37);
            this.btXoaGr.TabIndex = 13;
            this.btXoaGr.Text = "Xóa";
            this.btXoaGr.UseVisualStyleBackColor = true;
            // 
            // fmGroup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(837, 448);
            this.Controls.Add(this.btXoaGr);
            this.Controls.Add(this.btSaveGr);
            this.Controls.Add(this.btCancelGr);
            this.Controls.Add(this.btSuaGr);
            this.Controls.Add(this.btThemGr);
            this.Controls.Add(this.tbGroupID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbDepName);
            this.Controls.Add(this.tbGroupName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvShift);
            this.Name = "fmGroup";
            this.Text = "FUTAS";
            ((System.ComponentModel.ISupportInitialize)(this.dgvShift)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvShift;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbGroupName;
        private System.Windows.Forms.TextBox tbDepName;
        private System.Windows.Forms.TextBox tbGroupID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btThemGr;
        private System.Windows.Forms.Button btSuaGr;
        private System.Windows.Forms.Button btCancelGr;
        private System.Windows.Forms.Button btSaveGr;
        private System.Windows.Forms.Button btXoaGr;
    }
}