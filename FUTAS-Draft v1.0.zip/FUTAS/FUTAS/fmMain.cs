﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FUTAS
{
    public partial class fmMain : Form
    {
        public fmMain()
        {
            InitializeComponent();
        }

        private void fmMain_Load(object sender, EventArgs e)
        {

        }

        private void quảnLýBộPhậnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fmGroup fmg = new fmGroup();
            fmg.Show();
        }

        private void quảnLýnhânViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fmEmployee fme = new fmEmployee();
            fme.Show();
        }
    }
}
