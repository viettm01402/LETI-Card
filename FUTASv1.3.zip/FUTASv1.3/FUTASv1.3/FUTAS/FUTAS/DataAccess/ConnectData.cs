﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace FUTAS.DataAccess
{
    class ConnectData
    {
        private SqlConnection conn;
        private SqlDataAdapter dataAp;
        private DataTable dataTable;

        //Constructor
        public ConnectData()
        {
            Connect();
        }
        //ket noi
        public void Connect()
        {
            string strConn = @"Data Source=localhost;Initial Catalog=dbFUTASv2;Integrated Security=True";
            try
            {
                conn = new SqlConnection(strConn);
                conn.Open();
                conn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
        //DataTable 
        public DataTable GetDataTable(string sql)
        {
            //DataAP
            dataAp = new SqlDataAdapter(sql, conn);
            //DataTable
            dataTable = new DataTable();
            dataAp.Fill(dataTable);
            return dataTable;
        }
        //ExecuteQuery
        public bool ExecuteQuery(String sql)
        {
            int numRecordEffect = 0;
            try
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                SqlCommand cmd = new SqlCommand(sql,conn);
                numRecordEffect = cmd.ExecuteNonQuery();
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            if (numRecordEffect > 0)
                return true;
            return false;
        }
        //Get Last ID
        public string GetLastID(string nameTable, string nameFiled)
        {
            string sql = "SELECT TOP 1 " + nameFiled + " FROM " + nameTable + " ORDER BY " + nameFiled + " DESC";
            // thực hiện câu truy vấn trên
            GetDataTable(sql);
            return dataTable.Rows[0][nameFiled].ToString();
        }
        //Check Exist Value
        public bool CheckExistValue(string nameTable, string nameFiled, string value)
        {
            string sql = "SELECT * FROM " + nameTable + " WHERE " + nameFiled + " = '" + value + "'";
            GetDataTable(sql);
            // Count effect rows
            if (dataTable.Rows.Count > 0)
                return true;
            return false;
        }
        public bool CheckExistData(string nameTable)
        {
            string sql = "SELECT * FROM " + nameTable + " ";
            GetDataTable(sql);
            if (dataTable.Rows.Count > 0)
                return true;
            return false;
        }
    }
}
