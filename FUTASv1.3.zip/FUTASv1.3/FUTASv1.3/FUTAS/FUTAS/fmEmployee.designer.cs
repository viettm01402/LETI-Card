﻿namespace FUTAS
{
    partial class fmEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fmEmployee));
            this.label1 = new System.Windows.Forms.Label();
            this.tBEmpCode = new System.Windows.Forms.TextBox();
            this.tBEmpName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tBCardCode = new System.Windows.Forms.TextBox();
            this.label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbBoxGroup = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dtTimepJointDay = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.tbBaseSalary = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbBoxGender = new System.Windows.Forms.ComboBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.tblEmployeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewEmp = new System.Windows.Forms.DataGridView();
            this.EmpID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmpName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DOB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGender = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.CardID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGroup = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.JoinDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BaseSalary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label7 = new System.Windows.Forms.Label();
            this.dtTimepDOB = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.tblEmployeeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmp)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Mã Nhân Viên";
            // 
            // tBEmpCode
            // 
            this.tBEmpCode.Location = new System.Drawing.Point(94, 10);
            this.tBEmpCode.Name = "tBEmpCode";
            this.tBEmpCode.ReadOnly = true;
            this.tBEmpCode.Size = new System.Drawing.Size(157, 20);
            this.tBEmpCode.TabIndex = 2;
            // 
            // tBEmpName
            // 
            this.tBEmpName.Location = new System.Drawing.Point(94, 36);
            this.tBEmpName.Name = "tBEmpName";
            this.tBEmpName.Size = new System.Drawing.Size(157, 20);
            this.tBEmpName.TabIndex = 4;
            this.tBEmpName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBEmpName_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Họ Và Tên";
            // 
            // tBCardCode
            // 
            this.tBCardCode.Location = new System.Drawing.Point(94, 62);
            this.tBCardCode.Name = "tBCardCode";
            this.tBCardCode.Size = new System.Drawing.Size(157, 20);
            this.tBCardCode.TabIndex = 6;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(13, 65);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(44, 13);
            this.label.TabIndex = 5;
            this.label.Text = "Mã Thẻ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(592, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Bộ Phận";
            // 
            // cbBoxGroup
            // 
            this.cbBoxGroup.FormattingEnabled = true;
            this.cbBoxGroup.Location = new System.Drawing.Point(673, 4);
            this.cbBoxGroup.Name = "cbBoxGroup";
            this.cbBoxGroup.Size = new System.Drawing.Size(157, 21);
            this.cbBoxGroup.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(280, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Ngày Gia Nhập";
            // 
            // dtTimepJointDay
            // 
            this.dtTimepJointDay.Location = new System.Drawing.Point(366, 62);
            this.dtTimepJointDay.Name = "dtTimepJointDay";
            this.dtTimepJointDay.Size = new System.Drawing.Size(179, 20);
            this.dtTimepJointDay.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(592, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Lương Cơ Bản";
            // 
            // tbBaseSalary
            // 
            this.tbBaseSalary.Location = new System.Drawing.Point(673, 35);
            this.tbBaseSalary.Name = "tbBaseSalary";
            this.tbBaseSalary.Size = new System.Drawing.Size(157, 20);
            this.tbBaseSalary.TabIndex = 12;
            this.tbBaseSalary.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbBaseSalary_KeyPress);
            this.tbBaseSalary.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tbBaseSalary_MouseDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(280, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Giới Tính";
            // 
            // cbBoxGender
            // 
            this.cbBoxGender.FormattingEnabled = true;
            this.cbBoxGender.Location = new System.Drawing.Point(366, 35);
            this.cbBoxGender.Name = "cbBoxGender";
            this.cbBoxGender.Size = new System.Drawing.Size(75, 21);
            this.cbBoxGender.TabIndex = 14;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(15, 97);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(99, 42);
            this.btnAdd.TabIndex = 15;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Enabled = false;
            this.btnCancel.Location = new System.Drawing.Point(731, 97);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(99, 42);
            this.btnCancel.TabIndex = 16;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnDel
            // 
            this.btnDel.Location = new System.Drawing.Point(378, 97);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(99, 42);
            this.btnDel.TabIndex = 17;
            this.btnDel.Text = "Xóa";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(195, 97);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(99, 42);
            this.btnEdit.TabIndex = 18;
            this.btnEdit.Text = "Sửa";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.Location = new System.Drawing.Point(566, 97);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(99, 42);
            this.btnSave.TabIndex = 19;
            this.btnSave.Text = "Lưu";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
           
            // tblEmployeeBindingSource
            // 
            this.tblEmployeeBindingSource.DataMember = "tblEmployee";
            // 
          
            // 
            // dataGridViewEmp
            // 
            this.dataGridViewEmp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEmp.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EmpID,
            this.EmpName,
            this.DOB,
            this.colGender,
            this.CardID,
            this.colGroup,
            this.JoinDate,
            this.BaseSalary});
            this.dataGridViewEmp.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridViewEmp.Location = new System.Drawing.Point(0, 145);
            this.dataGridViewEmp.Name = "dataGridViewEmp";
            this.dataGridViewEmp.Size = new System.Drawing.Size(842, 350);
            this.dataGridViewEmp.TabIndex = 20;
            this.dataGridViewEmp.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewEmp_RowEnter);
            // 
            // EmpID
            // 
            this.EmpID.DataPropertyName = "EmpID";
            this.EmpID.HeaderText = "Mã nhân viên";
            this.EmpID.Name = "EmpID";
            this.EmpID.ReadOnly = true;
            // 
            // EmpName
            // 
            this.EmpName.DataPropertyName = "EmpName";
            this.EmpName.HeaderText = "Họ và tên";
            this.EmpName.Name = "EmpName";
            this.EmpName.ReadOnly = true;
            // 
            // DOB
            // 
            this.DOB.DataPropertyName = "DOB";
            this.DOB.HeaderText = "Ngày sinh";
            this.DOB.Name = "DOB";
            this.DOB.ReadOnly = true;
            // 
            // colGender
            // 
            this.colGender.DataPropertyName = "Gender";
            this.colGender.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.colGender.HeaderText = "Giới tính";
            this.colGender.Name = "colGender";
            this.colGender.ReadOnly = true;
            // 
            // CardID
            // 
            this.CardID.DataPropertyName = "CardID";
            this.CardID.HeaderText = "Mã thẻ";
            this.CardID.Name = "CardID";
            this.CardID.ReadOnly = true;
            // 
            // colGroup
            // 
            this.colGroup.DataPropertyName = "GroupID";
            this.colGroup.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.colGroup.HeaderText = "Bộ phận";
            this.colGroup.Name = "colGroup";
            this.colGroup.ReadOnly = true;
            this.colGroup.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colGroup.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // JoinDate
            // 
            this.JoinDate.DataPropertyName = "JoinDate";
            this.JoinDate.HeaderText = "Ngày gia nhập";
            this.JoinDate.Name = "JoinDate";
            this.JoinDate.ReadOnly = true;
            // 
            // BaseSalary
            // 
            this.BaseSalary.DataPropertyName = "BaseSalary";
            this.BaseSalary.HeaderText = "Lương cơ bản";
            this.BaseSalary.Name = "BaseSalary";
            this.BaseSalary.ReadOnly = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(280, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "Ngày Sinh";
            // 
            // dtTimepDOB
            // 
            this.dtTimepDOB.Location = new System.Drawing.Point(366, 7);
            this.dtTimepDOB.Name = "dtTimepDOB";
            this.dtTimepDOB.Size = new System.Drawing.Size(179, 20);
            this.dtTimepDOB.TabIndex = 22;
            // 
            // fmEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(842, 495);
            this.Controls.Add(this.dtTimepDOB);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dataGridViewEmp);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.cbBoxGender);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbBaseSalary);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dtTimepJointDay);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbBoxGroup);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tBCardCode);
            this.Controls.Add(this.label);
            this.Controls.Add(this.tBEmpName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tBEmpCode);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "fmEmployee";
            this.Text = "FUTAS -  Quản lý nhân viên";
            this.Load += new System.EventHandler(this.fmEmployee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tblEmployeeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tBEmpCode;
        private System.Windows.Forms.TextBox tBEmpName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tBCardCode;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbBoxGroup;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtTimepJointDay;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbBaseSalary;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbBoxGender;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.BindingSource tblEmployeeBindingSource;
        private System.Windows.Forms.DataGridView dataGridViewEmp;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtTimepDOB;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmpID;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmpName;
        private System.Windows.Forms.DataGridViewTextBoxColumn DOB;
        private System.Windows.Forms.DataGridViewComboBoxColumn colGender;
        private System.Windows.Forms.DataGridViewTextBoxColumn CardID;
        private System.Windows.Forms.DataGridViewComboBoxColumn colGroup;
        private System.Windows.Forms.DataGridViewTextBoxColumn JoinDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn BaseSalary;
    }
}