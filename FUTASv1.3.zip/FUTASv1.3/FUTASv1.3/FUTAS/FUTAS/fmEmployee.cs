﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FUTAS.DataAccess;
using FUTAS.BusinessLogic;
using FUTAS.BusinessObject;

namespace FUTAS
{
    public partial class fmEmployee : Form
    {
        private EmployeeBUS empBUS = new EmployeeBUS();
        private GroupBUS grBUS = new GroupBUS();
        ConnectData connData = new ConnectData();

        public fmEmployee()
        {
            InitializeComponent();
        }

        private void fmEmployee_Load(object sender, EventArgs e)
        {
           
           

            //Load ten nhom cho combobox
            cbBoxGroup.DataSource = grBUS.GetAllGroup();
            cbBoxGroup.DisplayMember = "GroupName";
            cbBoxGroup.ValueMember = "GroupID";

            //Load gioi tinh cho combobox
            cbBoxGender.DataSource = empBUS.GetGenderEmployee();
            cbBoxGender.DisplayMember = "NameGT";
            cbBoxGender.ValueMember = "Gender";

            //load datagridview
            colGender.DataSource = empBUS.GetGenderEmployee();
            colGender.DisplayMember = "NameGT";
            colGender.ValueMember = "Gender";

            colGroup.DataSource = grBUS.GetAllGroup();
            colGroup.DisplayMember = "GroupName";
            colGroup.ValueMember = "GroupID";

            //Load dataGribView
            dataGridViewEmp.DataSource = empBUS.GetListEmployee();
            EnableEditing(false);
        }
        
        private void dataGridViewEmp_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            //dong hien tai
            int dong = e.RowIndex;
            //binding data len control, khi clik vao row datagridview
            tBEmpCode.Text = dataGridViewEmp.Rows[dong].Cells["EmpID"].Value.ToString();
            tBEmpName.Text = dataGridViewEmp.Rows[dong].Cells["EmpName"].Value.ToString();
            tBCardCode.Text = dataGridViewEmp.Rows[dong].Cells["CardID"].Value.ToString();
            dtTimepDOB.Text = dataGridViewEmp.Rows[dong].Cells["DOB"].Value.ToString();
            dtTimepJointDay.Text = dataGridViewEmp.Rows[dong].Cells["JoinDate"].Value.ToString();
            tbBaseSalary.Text = dataGridViewEmp.Rows[dong].Cells["BaseSalary"].Value.ToString();
            cbBoxGender.SelectedValue = dataGridViewEmp.Rows[dong].Cells["colGender"].Value.ToString();
            cbBoxGroup.SelectedValue = dataGridViewEmp.Rows[dong].Cells["colGroup"].Value.ToString(); 
            
        }

        public void EnableEditing (bool editing)
        {
            btnAdd.Enabled = !editing;
            btnEdit.Enabled = !editing;
            btnDel.Enabled = !editing;
            btnSave.Enabled = editing;
            btnCancel.Enabled = editing;
            //textbox, combobox
            tBEmpName.Enabled = editing;
            tBCardCode.Enabled = editing;
            tbBaseSalary.Enabled = editing;
            dtTimepDOB.Enabled = editing;
            dtTimepJointDay.Enabled = editing;
            cbBoxGender.Enabled = editing;
            cbBoxGroup.Enabled = editing;
            //Data gridview
            dataGridViewEmp.Enabled = !editing;
        }

        private void ResetTextValue() 
        {
            tBEmpName.Text = "";
            tBCardCode.Text = "";
            tbBaseSalary.Text = "0";
            dtTimepDOB.Text = "";
            dtTimepJointDay.Text = "";
        }

        
        private void btnAdd_Click(object sender, EventArgs e)
        {
            EnableEditing(true);
            ResetTextValue();
            Employee emp = new Employee();
            tBEmpCode.Text = empBUS.NextID();

        }
        private Employee getInputData() 
        {

            Employee emp = new Employee();
            emp.EmpID = int.Parse(tBEmpCode.Text.ToString());
            emp.EmpName = tBEmpName.Text;
            emp.DOB = Convert.ToDateTime(dtTimepDOB.Value.ToShortDateString());
            emp.CardID = tBCardCode.Text;
            emp.Gender = (cbBoxGender.SelectedValue.ToString() == "True") ? 1 : 0;
            emp.GroupID = Convert.ToInt32(cbBoxGroup.SelectedValue.ToString());
            emp.JoinDate = Convert.ToDateTime(dtTimepJointDay.Value.ToShortDateString());
            emp.BaseSalary = float.Parse(tbBaseSalary.Text);
            int TotalDOL = 12 - int.Parse(dtTimepJointDay.Value.Month.ToString());
            emp.TotalDayOnLeave = TotalDOL;
            return emp;
            
        }
        
        private void btnSave_Click(object sender, EventArgs e)
        {
            Employee emp = getInputData();
            if (empBUS.CheckExits(emp.EmpID))
            {
                if (empBUS.EditEmp(emp))
                {
                    fmEmployee_Load(sender, e);
                }
                
            }
            else 
            {

                if (connData.CheckExistValue("tblEmployee", "CardID", emp.CardID) == true)
                {
                    MessageBox.Show("Trùng mã thẻ", "", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                else
                {
                    if (empBUS.AddEmp(emp))
                    {
                        fmEmployee_Load(sender, e);
                    }
                }
            }
            
        }

        /*
          private void btnSave_Click(object sender, EventArgs e)
        {
            Employee emp = getInputData();
            if (connData.CheckExistValue("tblEmployee", "CardID", emp.CardID) == true)
            {
                MessageBox.Show("Trùng mã thẻ", "", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                if (empBUS.AddEmp(emp))
                {
                    fmEmployee_Load(sender, e);
                }
            }
            
        }
         */
        private void tbBaseSalary_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar)&&!char.IsControl(e.KeyChar)&&!char.IsSymbol(e.KeyChar))
            {
                MessageBox.Show("Chỉ nhập kí tự số","",MessageBoxButtons.OK,MessageBoxIcon.Error);
                e.Handled = true;
            }
        }

        private void tBEmpName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                MessageBox.Show("Không nhập ký tự số", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Handled = true;
            }
        }

        private void tbBaseSalary_MouseDown(object sender, MouseEventArgs e)
        {
            tbBaseSalary.Clear();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            EnableEditing(true);
            tBCardCode.Enabled = false;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            fmEmployee_Load(sender, e);
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn xóa nhân viên: " + tBEmpName.Text + " không?", "", 
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (empBUS.DeleteEmp(tBEmpCode.Text))
                    fmEmployee_Load(sender,e);
            }
        }        
    }
}
