﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

using FUTAS.BusinessLogic;
using FUTAS.BusinessObject;
namespace FUTAS
{
    public partial class fmOT : Form
    {
        private OTBUS otBUS = new OTBUS();
        public fmOT()
        {
            InitializeComponent();
        }

        private void fmOT_Load(object sender, EventArgs e)
        {
            dtgOT.DataSource = otBUS.GetAllOT();
            EnableEditing(false);
        }

        private void dtgOT_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            //Recent Row
            int recentRow = e.RowIndex;
            try
            {
                //Load data to textbox
                txtOtID.Text = dtgOT.Rows[recentRow].Cells["OtID"].Value.ToString();
                txtOtName.Text = dtgOT.Rows[recentRow].Cells["OtName"].Value.ToString();
                txtStartTime.Text = dtgOT.Rows[recentRow].Cells["OtStartTime"].Value.ToString();
                txtEndTime.Text = dtgOT.Rows[recentRow].Cells["OtEndTime"].Value.ToString();
                txtOtRate.Text = dtgOT.Rows[recentRow].Cells["OtRate"].Value.ToString();
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Lỗi: "+ex.Message,"Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
        //KeyPress
        private void txtOtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) && !Char.IsControl(e.KeyChar) && !Char.IsWhiteSpace(e.KeyChar) && !Char.IsDigit(e.KeyChar))
                e.Handled = true;
        }
        private void txtOtRate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
                MessageBox.Show("Phải nhập số thực","Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
        private void EnableEditing(bool editing)
        {
            //Buttons
            btnAdd.Enabled = !editing;
            btnUpdate.Enabled = !editing;
            btnDelete.Enabled = !editing;
            btnSave.Enabled = editing;
            btnCancel.Enabled = editing;
            //Textbox
            txtOtName.Enabled = editing;
            txtOtRate.Enabled = editing;
            txtStartTime.Enabled = editing;
            txtEndTime.Enabled = editing;
            //Datagridview
            dtgOT.Enabled = !editing;
        }
        private void ResetTextbox()
        {
            txtOtName.Text = "";
            txtOtRate.Text = "1";
            txtStartTime.Text = "";
            txtEndTime.Text = "";
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            EnableEditing(true);
            ResetTextbox();
            txtOtID.Text = otBUS.NextID();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            fmOT_Load(sender, e);
        }
        //GetInPutData
        private OT GetInputData()
        {
            OT ot = new OT();
            ot.OtID = int.Parse(txtOtID.Text);
            ot.OtName = txtOtName.Text;
            var sTime = TimeSpan.Parse(txtStartTime.Text);
            ot.OtStartTime = Convert.ToDateTime(sTime.ToString());
            var eTime = TimeSpan.Parse(txtEndTime.Text);
            ot.OtEndTime = Convert.ToDateTime(eTime.ToString());
            ot.OtRate = float.Parse(txtOtRate.Text);
            return ot;
        }
        private bool checkinputStartTime() 
        {
            string sTime = txtStartTime.Text;
            Regex regex = new Regex(@"^(23|22|21|20|[0-1][0-9])\:([0-5][0-9])\:([0-5][0-9])$");
            if (regex.IsMatch(sTime) == false) 
            {
                MessageBox.Show("Giờ phải theo cú pháp 00:00:00","Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private bool checkinputEndTime()
        {
            string eTime = txtEndTime.Text;
            Regex regex = new Regex(@"^(23|22|21|20|[0-1][0-9])\:([0-5][0-9])\:([0-5][0-9])$");
            if (regex.IsMatch(eTime) == false)
            {
                MessageBox.Show("Giờ phải theo cú pháp 00:00:00", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private bool checkinputRate()
        {
            String rate = txtOtRate.Text;
            Regex regex = new Regex(@"^[+]?[0-9]*\.?[0-9]+$");
            if(regex.IsMatch(rate) == false)
            {
                MessageBox.Show("Hệ số không đúng", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (checkinputStartTime() && checkinputEndTime() && checkinputRate())
            {
                OT ot = GetInputData();
                if (otBUS.CheckExistID(ot.OtID.ToString()))
                {
                    if (otBUS.UpdateOT(ot))
                        fmOT_Load(sender, e);
                }
                else
                {
                    if (otBUS.AddOT(ot))
                        fmOT_Load(sender, e);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            EnableEditing(true);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn xóa ca OT: " + txtOtName.Text + " không?", "Xóa caOT", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                otBUS.DeleteOT(txtOtID.Text);
                fmOT_Load(sender, e);
            }
        }

        
    }
}
