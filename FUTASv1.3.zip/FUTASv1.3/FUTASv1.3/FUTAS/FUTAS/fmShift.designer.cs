﻿namespace FUTAS
{
    partial class fmShift
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSave = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.tBShiftDesc = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tBShiftType = new System.Windows.Forms.TextBox();
            this.tBCardCode = new System.Windows.Forms.Label();
            this.tBShiftName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tBShiftCode = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewShift = new System.Windows.Forms.DataGridView();
            this.ShiftID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ShiftName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StartTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EndTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ShiftType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ShiftDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tBShiftStartTime = new System.Windows.Forms.TextBox();
            this.tBShiftEndTime = new System.Windows.Forms.TextBox();
            this.tBShiftRate = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShift)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(567, 92);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(99, 42);
            this.btnSave.TabIndex = 39;
            this.btnSave.Text = "Lưu";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(196, 92);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(99, 42);
            this.btnEdit.TabIndex = 38;
            this.btnEdit.Text = "Sửa";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnDel
            // 
            this.btnDel.Location = new System.Drawing.Point(379, 92);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(99, 42);
            this.btnDel.TabIndex = 37;
            this.btnDel.Text = "Xóa";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(732, 92);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(99, 42);
            this.btnCancel.TabIndex = 36;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(16, 92);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(99, 42);
            this.btnAdd.TabIndex = 35;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(699, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 33;
            this.label6.Text = "Mức lương";
            // 
            // tBShiftDesc
            // 
            this.tBShiftDesc.Location = new System.Drawing.Point(431, 58);
            this.tBShiftDesc.Name = "tBShiftDesc";
            this.tBShiftDesc.Size = new System.Drawing.Size(200, 20);
            this.tBShiftDesc.TabIndex = 32;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(345, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 31;
            this.label5.Text = "Chi tiết";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(345, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 13);
            this.label4.TabIndex = 29;
            this.label4.Text = "Giờ kết thúc ca";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(345, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 27;
            this.label3.Text = "Giờ bắt đầu ca";
            // 
            // tBShiftType
            // 
            this.tBShiftType.Location = new System.Drawing.Point(94, 58);
            this.tBShiftType.Name = "tBShiftType";
            this.tBShiftType.Size = new System.Drawing.Size(172, 20);
            this.tBShiftType.TabIndex = 26;
            // 
            // tBCardCode
            // 
            this.tBCardCode.AutoSize = true;
            this.tBCardCode.Location = new System.Drawing.Point(13, 61);
            this.tBCardCode.Name = "tBCardCode";
            this.tBCardCode.Size = new System.Drawing.Size(84, 13);
            this.tBCardCode.TabIndex = 25;
            this.tBCardCode.Text = "Loại ca làm việc";
            // 
            // tBShiftName
            // 
            this.tBShiftName.Location = new System.Drawing.Point(94, 32);
            this.tBShiftName.Name = "tBShiftName";
            this.tBShiftName.Size = new System.Drawing.Size(172, 20);
            this.tBShiftName.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "Tên ca làm việc";
            // 
            // tBShiftCode
            // 
            this.tBShiftCode.Location = new System.Drawing.Point(94, 6);
            this.tBShiftCode.Name = "tBShiftCode";
            this.tBShiftCode.ReadOnly = true;
            this.tBShiftCode.Size = new System.Drawing.Size(172, 20);
            this.tBShiftCode.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Mã ca làm việc";
            // 
            // dataGridViewShift
            // 
            this.dataGridViewShift.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ShiftID,
            this.ShiftName,
            this.StartTime,
            this.EndTime,
            this.ShiftType,
            this.ShiftDescription,
            this.Rate});
            this.dataGridViewShift.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridViewShift.Location = new System.Drawing.Point(0, 161);
            this.dataGridViewShift.Name = "dataGridViewShift";
            this.dataGridViewShift.ReadOnly = true;
            this.dataGridViewShift.Size = new System.Drawing.Size(883, 335);
            this.dataGridViewShift.TabIndex = 20;
            this.dataGridViewShift.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewShift_RowEnter);
            // 
            // ShiftID
            // 
            this.ShiftID.DataPropertyName = "ShiftID";
            this.ShiftID.HeaderText = "Mã ca làm việc";
            this.ShiftID.Name = "ShiftID";
            this.ShiftID.ReadOnly = true;
            // 
            // ShiftName
            // 
            this.ShiftName.DataPropertyName = "ShiftName";
            this.ShiftName.HeaderText = "Tên ca làm việc";
            this.ShiftName.Name = "ShiftName";
            this.ShiftName.ReadOnly = true;
            // 
            // StartTime
            // 
            this.StartTime.DataPropertyName = "StartTime";
            this.StartTime.HeaderText = "Giờ bắt đầu ca";
            this.StartTime.Name = "StartTime";
            this.StartTime.ReadOnly = true;
            // 
            // EndTime
            // 
            this.EndTime.DataPropertyName = "EndTime";
            this.EndTime.HeaderText = "Giờ kết thúc ca";
            this.EndTime.Name = "EndTime";
            this.EndTime.ReadOnly = true;
            // 
            // ShiftType
            // 
            this.ShiftType.DataPropertyName = "ShiftType";
            this.ShiftType.HeaderText = "Loại ca làm việc";
            this.ShiftType.Name = "ShiftType";
            this.ShiftType.ReadOnly = true;
            // 
            // ShiftDescription
            // 
            this.ShiftDescription.DataPropertyName = "ShiftDescription";
            this.ShiftDescription.HeaderText = "Chi tiết";
            this.ShiftDescription.Name = "ShiftDescription";
            this.ShiftDescription.ReadOnly = true;
            // 
            // Rate
            // 
            this.Rate.DataPropertyName = "Rate";
            this.Rate.HeaderText = "Mức lương";
            this.Rate.Name = "Rate";
            this.Rate.ReadOnly = true;
            // 
            // tBShiftStartTime
            // 
            this.tBShiftStartTime.Location = new System.Drawing.Point(431, 6);
            this.tBShiftStartTime.Name = "tBShiftStartTime";
            this.tBShiftStartTime.Size = new System.Drawing.Size(200, 20);
            this.tBShiftStartTime.TabIndex = 40;
            // 
            // tBShiftEndTime
            // 
            this.tBShiftEndTime.Location = new System.Drawing.Point(431, 32);
            this.tBShiftEndTime.Name = "tBShiftEndTime";
            this.tBShiftEndTime.Size = new System.Drawing.Size(200, 20);
            this.tBShiftEndTime.TabIndex = 41;
            // 
            // tBShiftRate
            // 
            this.tBShiftRate.Location = new System.Drawing.Point(762, 6);
            this.tBShiftRate.Name = "tBShiftRate";
            this.tBShiftRate.Size = new System.Drawing.Size(74, 20);
            this.tBShiftRate.TabIndex = 42;
            // 
            // fmShift
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(883, 496);
            this.Controls.Add(this.tBShiftRate);
            this.Controls.Add(this.tBShiftEndTime);
            this.Controls.Add(this.tBShiftStartTime);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tBShiftDesc);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tBShiftType);
            this.Controls.Add(this.tBCardCode);
            this.Controls.Add(this.tBShiftName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tBShiftCode);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridViewShift);
            this.Name = "fmShift";
            this.Text = "fmShift";
            this.Load += new System.EventHandler(this.fmShift_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShift)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tBShiftDesc;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tBShiftType;
        private System.Windows.Forms.Label tBCardCode;
        private System.Windows.Forms.TextBox tBShiftName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tBShiftCode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridViewShift;
        private System.Windows.Forms.TextBox tBShiftStartTime;
        private System.Windows.Forms.TextBox tBShiftEndTime;
        private System.Windows.Forms.TextBox tBShiftRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ShiftID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ShiftName;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn EndTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn ShiftType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ShiftDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rate;
    }
}