﻿namespace FUTAS
{
    partial class fmGroupDist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cboGroupName = new System.Windows.Forms.ComboBox();
            this.cboShiftName = new System.Windows.Forms.ComboBox();
            this.dataGridViewGrDist = new System.Windows.Forms.DataGridView();
            this.GRID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGroupName = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colShiftName = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tBGRID = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGrDist)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(225, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(176, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Phân ca làm việc";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(149, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nhóm";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(375, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Ca làm việc";
            // 
            // cboGroupName
            // 
            this.cboGroupName.FormattingEnabled = true;
            this.cboGroupName.Location = new System.Drawing.Point(219, 66);
            this.cboGroupName.Name = "cboGroupName";
            this.cboGroupName.Size = new System.Drawing.Size(121, 21);
            this.cboGroupName.TabIndex = 3;
            // 
            // cboShiftName
            // 
            this.cboShiftName.FormattingEnabled = true;
            this.cboShiftName.Location = new System.Drawing.Point(468, 66);
            this.cboShiftName.Name = "cboShiftName";
            this.cboShiftName.Size = new System.Drawing.Size(121, 21);
            this.cboShiftName.TabIndex = 4;
            // 
            // dataGridViewGrDist
            // 
            this.dataGridViewGrDist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewGrDist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.GRID,
            this.colGroupName,
            this.colShiftName});
            this.dataGridViewGrDist.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridViewGrDist.Location = new System.Drawing.Point(0, 210);
            this.dataGridViewGrDist.Name = "dataGridViewGrDist";
            this.dataGridViewGrDist.ReadOnly = true;
            this.dataGridViewGrDist.Size = new System.Drawing.Size(652, 176);
            this.dataGridViewGrDist.TabIndex = 5;
            this.dataGridViewGrDist.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewGrDist_RowEnter);
            // 
            // GRID
            // 
            this.GRID.DataPropertyName = "GRID";
            this.GRID.HeaderText = "Số thứ tự";
            this.GRID.Name = "GRID";
            this.GRID.ReadOnly = true;
            // 
            // colGroupName
            // 
            this.colGroupName.DataPropertyName = "GroupID";
            this.colGroupName.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.colGroupName.HeaderText = "Tên nhóm làm việc";
            this.colGroupName.Name = "colGroupName";
            this.colGroupName.ReadOnly = true;
            this.colGroupName.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colGroupName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // colShiftName
            // 
            this.colShiftName.DataPropertyName = "ShiftID";
            this.colShiftName.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.colShiftName.HeaderText = "Tên ca làm việc";
            this.colShiftName.Name = "colShiftName";
            this.colShiftName.ReadOnly = true;
            this.colShiftName.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colShiftName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(33, 139);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(99, 42);
            this.btnAdd.TabIndex = 6;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(152, 139);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(99, 42);
            this.btnEdit.TabIndex = 7;
            this.btnEdit.Text = "Sửa";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnDel
            // 
            this.btnDel.Location = new System.Drawing.Point(270, 139);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(99, 42);
            this.btnDel.TabIndex = 8;
            this.btnDel.Text = "Xóa";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(390, 139);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(99, 42);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Lưu";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(521, 139);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(99, 42);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Stt";
            // 
            // tBGRID
            // 
            this.tBGRID.Location = new System.Drawing.Point(43, 66);
            this.tBGRID.Name = "tBGRID";
            this.tBGRID.ReadOnly = true;
            this.tBGRID.Size = new System.Drawing.Size(55, 20);
            this.tBGRID.TabIndex = 12;
            // 
            // fmGroupDist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(652, 386);
            this.Controls.Add(this.tBGRID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dataGridViewGrDist);
            this.Controls.Add(this.cboShiftName);
            this.Controls.Add(this.cboGroupName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "fmGroupDist";
            this.Text = "fmGroupRecords";
            this.Load += new System.EventHandler(this.fmGroupRecords_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGrDist)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboGroupName;
        private System.Windows.Forms.ComboBox cboShiftName;
        private System.Windows.Forms.DataGridView dataGridViewGrDist;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DataGridViewTextBoxColumn GRID;
        private System.Windows.Forms.DataGridViewComboBoxColumn colGroupName;
        private System.Windows.Forms.DataGridViewComboBoxColumn colShiftName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tBGRID;
    }
}