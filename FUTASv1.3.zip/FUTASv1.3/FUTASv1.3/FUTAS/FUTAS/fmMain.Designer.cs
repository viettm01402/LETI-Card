﻿namespace FUTAS
{
    partial class fmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýnhânViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýBộPhậnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýcaLàmViệcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemShiftDistribution = new System.Windows.Forms.ToolStripMenuItem();
            this.itemOLOT = new System.Windows.Forms.ToolStripMenuItem();
            this.itemOTDistribution = new System.Windows.Forms.ToolStripMenuItem();
            this.itemReader = new System.Windows.Forms.ToolStripMenuItem();
            this.chấmCôngVàtínhLươngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xuấtBáoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ConnectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giớiThiệuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.comPort = new System.IO.Ports.SerialPort(this.components);
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThốngToolStripMenuItem,
            this.ConnectToolStripMenuItem,
            this.trợGiúpToolStripMenuItem,
            this.giớiThiệuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(841, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hệThốngToolStripMenuItem
            // 
            this.hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýnhânViênToolStripMenuItem,
            this.quảnLýBộPhậnToolStripMenuItem,
            this.quảnLýcaLàmViệcToolStripMenuItem,
            this.itemOLOT,
            this.itemReader,
            this.chấmCôngVàtínhLươngToolStripMenuItem,
            this.xuấtBáoCáoToolStripMenuItem,
            this.đăngXuấtToolStripMenuItem});
            this.hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            this.hệThốngToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.hệThốngToolStripMenuItem.Text = "&Hệ Thống";
            // 
            // quảnLýnhânViênToolStripMenuItem
            // 
            this.quảnLýnhânViênToolStripMenuItem.Name = "quảnLýnhânViênToolStripMenuItem";
            this.quảnLýnhânViênToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.quảnLýnhânViênToolStripMenuItem.Text = "Quản lý &nhân viên";
            this.quảnLýnhânViênToolStripMenuItem.Click += new System.EventHandler(this.quảnLýnhânViênToolStripMenuItem_Click);
            // 
            // quảnLýBộPhậnToolStripMenuItem
            // 
            this.quảnLýBộPhậnToolStripMenuItem.Name = "quảnLýBộPhậnToolStripMenuItem";
            this.quảnLýBộPhậnToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.quảnLýBộPhậnToolStripMenuItem.Text = "Quản lý &phòng ban";
            this.quảnLýBộPhậnToolStripMenuItem.Click += new System.EventHandler(this.quảnLýBộPhậnToolStripMenuItem_Click);
            // 
            // quảnLýcaLàmViệcToolStripMenuItem
            // 
            this.quảnLýcaLàmViệcToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itemShiftDistribution});
            this.quảnLýcaLàmViệcToolStripMenuItem.Name = "quảnLýcaLàmViệcToolStripMenuItem";
            this.quảnLýcaLàmViệcToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.quảnLýcaLàmViệcToolStripMenuItem.Text = "Quản lý &ca làm việc";
            this.quảnLýcaLàmViệcToolStripMenuItem.Click += new System.EventHandler(this.quảnLýcaLàmViệcToolStripMenuItem_Click);
            // 
            // itemShiftDistribution
            // 
            this.itemShiftDistribution.Name = "itemShiftDistribution";
            this.itemShiftDistribution.Size = new System.Drawing.Size(163, 22);
            this.itemShiftDistribution.Text = "Phân ca làm việc";
            this.itemShiftDistribution.Click += new System.EventHandler(this.itemShiftDistribution_Click);
            // 
            // itemOLOT
            // 
            this.itemOLOT.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itemOTDistribution});
            this.itemOLOT.Name = "itemOLOT";
            this.itemOLOT.Size = new System.Drawing.Size(213, 22);
            this.itemOLOT.Text = "Quản lý &OT";
            this.itemOLOT.Click += new System.EventHandler(this.itemOLOT_Click);
            // 
            // itemOTDistribution
            // 
            this.itemOTDistribution.Name = "itemOTDistribution";
            this.itemOTDistribution.Size = new System.Drawing.Size(135, 22);
            this.itemOTDistribution.Text = "Phân ca OT";
            this.itemOTDistribution.Click += new System.EventHandler(this.itemOTDistribution_Click);
            // 
            // itemReader
            // 
            this.itemReader.Name = "itemReader";
            this.itemReader.Size = new System.Drawing.Size(213, 22);
            this.itemReader.Text = "Quản lý đầu đọc (&Readers)";
            this.itemReader.Click += new System.EventHandler(this.itemReader_Click);
            // 
            // chấmCôngVàtínhLươngToolStripMenuItem
            // 
            this.chấmCôngVàtínhLươngToolStripMenuItem.Name = "chấmCôngVàtínhLươngToolStripMenuItem";
            this.chấmCôngVàtínhLươngToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.chấmCôngVàtínhLươngToolStripMenuItem.Text = "Chấm công và &tính lương";
            // 
            // xuấtBáoCáoToolStripMenuItem
            // 
            this.xuấtBáoCáoToolStripMenuItem.Name = "xuấtBáoCáoToolStripMenuItem";
            this.xuấtBáoCáoToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.xuấtBáoCáoToolStripMenuItem.Text = "&Xuất báo cáo";
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.đăngXuấtToolStripMenuItem.Text = "&Đăng xuất";
            // 
            // ConnectToolStripMenuItem
            // 
            this.ConnectToolStripMenuItem.Name = "ConnectToolStripMenuItem";
            this.ConnectToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.ConnectToolStripMenuItem.Text = "&Kết Nối";
            this.ConnectToolStripMenuItem.Click += new System.EventHandler(this.ConnectToolStripMenuItem_Click);
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.trợGiúpToolStripMenuItem.Text = "&Trợ Giúp";
            // 
            // giớiThiệuToolStripMenuItem
            // 
            this.giớiThiệuToolStripMenuItem.Name = "giớiThiệuToolStripMenuItem";
            this.giớiThiệuToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.giớiThiệuToolStripMenuItem.Text = "&Giới Thiệu";
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // fmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(841, 509);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "fmMain";
            this.Text = "FUTAS";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.fmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýnhânViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýcaLàmViệcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chấmCôngVàtínhLươngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xuấtBáoCáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýBộPhậnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemOLOT;
        private System.Windows.Forms.ToolStripMenuItem itemOTDistribution;
        private System.Windows.Forms.ToolStripMenuItem itemReader;
        private System.Windows.Forms.ToolStripMenuItem itemShiftDistribution;
        private System.Windows.Forms.ToolStripMenuItem ConnectToolStripMenuItem;
        private System.Windows.Forms.Timer timer;
        private System.IO.Ports.SerialPort comPort;
    }
}

