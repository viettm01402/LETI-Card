﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using FUTAS.BusinessLogic;
using FUTAS.BusinessObject;

namespace FUTAS
{
    public partial class fmReader : Form
    {
        ReaderBUS readerBUS = new ReaderBUS();
        bool flagchangepass = false;
        public fmReader()
        {
            InitializeComponent();
        }

        private void fmReader_Load(object sender, EventArgs e)
        {
            cblReaderStatus.DataSource = readerBUS.GetReaderStatus();
            cblReaderStatus.DisplayMember = "NameStatus";
            cblReaderStatus.ValueMember = "ReaderStatus";
            dtgReader.DataSource = readerBUS.GetAllReader();
            btnChangePass.Enabled = false;
            flagchangepass = false;
            EnableEditing(false);

        }

        private void dtgReader_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            int recentrow = e.RowIndex;
            try
            {
                txtReaderID.Text = dtgReader.Rows[recentrow].Cells["ReaderID"].Value.ToString();
                txtReaderIP.Text = dtgReader.Rows[recentrow].Cells["ReaderIP"].Value.ToString();
                txtPass.Text = dtgReader.Rows[recentrow].Cells["ReaderPass"].Value.ToString();
                txtRePass.Text = dtgReader.Rows[recentrow].Cells["ReaderPass"].Value.ToString();
            }
            catch (Exception) 
            {
                MessageBox.Show("Không thể chọn nhiều dòng 1 lúc","Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
        private void EnableEditing(bool editing)
        {
            //Buttons
            btnAdd.Enabled = !editing;
            btnUpdate.Enabled = !editing;
            btnDelete.Enabled = !editing;
            btnSave.Enabled = editing;
            btnCancel.Enabled = editing;
            //Textbox
            txtReaderIP.Enabled = editing;
            txtPass.Enabled = editing;
            txtRePass.Enabled = editing;
            //Datagridview
            dtgReader.Enabled = !editing;
        }
        private void ResetTextbox()
        {
            txtReaderIP.Text = "";
            txtPass.Text = "";
            txtRePass.Text = "";
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            EnableEditing(true);
            txtReaderID.Text = readerBUS.NextID();
            ResetTextbox();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            fmReader_Load(sender, e);
        }

        private Reader getinputdata() 
        {
            Reader r = new Reader();
            r.ReaderID = int.Parse(txtReaderID.Text);
            r.ReaderIP = txtReaderIP.Text;
            r.ReaderStatus = 0;
            return r;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if(txtPass.Text.Equals(""))
                MessageBox.Show("Mật khẩu không được để trống", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                if (txtPass.Text.Equals(txtRePass.Text) == false)
                    MessageBox.Show("Nhập lại mật khẩu và mật khẩu phải trùng nhau", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                {
                    Reader r = getinputdata();
                    if (readerBUS.checkReaderID(r.ReaderID.ToString()))
                    {
                        if (flagchangepass == false)
                        {
                            r.ReaderPass = txtPass.Text;
                            if (readerBUS.UpdateReader(r, false))
                                fmReader_Load(sender, e);
                        }
                        else
                        {
                            r.ReaderPass = Utilitiescs.md5(txtPass.Text);
                            if (readerBUS.UpdateReader(r, true))
                                fmReader_Load(sender, e);
                        }
                    }
                    else
                    {
                        if (readerBUS.checkReaderIP(r.ReaderIP))
                        {

                            r.ReaderPass = Utilitiescs.md5(txtPass.Text);
                            if (readerBUS.AddReader(r))
                                fmReader_Load(sender, e);
                        }
                    }

                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            EnableEditing(true);
            btnChangePass.Enabled = true;
            txtPass.Enabled = txtRePass.Enabled = false;
        }

        private void btnChangePass_Click(object sender, EventArgs e)
        {
            flagchangepass = true;
            txtPass.Text = "";
            txtRePass.Text = "";
            txtPass.Enabled = txtRePass.Enabled = true;
            btnChangePass.Enabled = false;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn xóa đầu đọc: " + txtReaderIP.Text + " không?", "Xóa nhóm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                if (readerBUS.DeleteReader(txtReaderID.Text))
                    fmReader_Load(sender, e);
            }
        }
    }
}
