﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using FUTAS.BusinessLogic;
using FUTAS.BusinessObject;

namespace FUTAS
{
    public partial class fmGroup : Form
    {
        private GroupBUS groupBUS = new GroupBUS();
        public fmGroup()
        {
            InitializeComponent();
        }

        private void fmGroup_Load(object sender, EventArgs e)
        {
            
            dtgGroup.DataSource = groupBUS.GetAllGroup();
            EnableEditing(false);
            
        }

        private void dtgGroup_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            //Recent Row
            int recentRow = e.RowIndex;
            try
            {
                //Load data to textbox
                txtGroupID.Text = dtgGroup.Rows[recentRow].Cells["GroupID"].Value.ToString();
                txtGroupName.Text = dtgGroup.Rows[recentRow].Cells["GroupName"].Value.ToString();
                txtDepart.Text = dtgGroup.Rows[recentRow].Cells["Department"].Value.ToString();
            }
            catch (Exception) 
            {
                MessageBox.Show("Không thể chọn nhiều dòng một lúc","Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void txtGroupName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) && !Char.IsControl(e.KeyChar) && !Char.IsWhiteSpace(e.KeyChar) && !Char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Không nhập ký tự đặc biệt", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Handled = true;
            }
        }

        private void txtDepart_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) && !Char.IsControl(e.KeyChar) && !Char.IsWhiteSpace(e.KeyChar) && !Char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Không nhập ký tự đặc biệt","Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
                e.Handled = true;
            }
        }

        private void EnableEditing(bool editing) 
        {
            //Buttons
            btnAdd.Enabled = !editing;
            btnUpdate.Enabled = !editing;
            btnDelete.Enabled = !editing;
            btnSave.Enabled = editing;
            btnCancel.Enabled = editing;
            //Textbox
            txtGroupName.Enabled = editing;
            txtDepart.Enabled = editing;
            //Datagridview
            dtgGroup.Enabled = !editing;
        }
        private void ResetTextbox()
        {
            txtGroupName.Text = "";
            txtDepart.Text = "";
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            EnableEditing(true);
            ResetTextbox();
            txtGroupID.Text = groupBUS.NextID();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            Group g = GetInputData();
            if (groupBUS.CheckExistID(g.GroupID.ToString()))
            {
                if (groupBUS.UpdateGroup(g))
                    fmGroup_Load(sender, e);
            }
            else 
            {
                if(groupBUS.AddGroup(g))
                    fmGroup_Load(sender, e);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtGroupID.Text.Equals("1"))
            {
                MessageBox.Show("Không thể sửa được thông tin nhóm mặc định", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                EnableEditing(true);
            }

        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            fmGroup_Load(sender, e);
           
        }
        //Get input data
        private Group GetInputData() 
        {
            Group g = new Group();
            g.GroupID = int.Parse(txtGroupID.Text);
            g.GroupName = txtGroupName.Text;
            g.Department = txtDepart.Text;
            return g;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtGroupID.Text.Equals("1"))
            {
                MessageBox.Show("Không thể xóa nhóm mặc định", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else 
            {
                if (MessageBox.Show("Bạn có muốn xóa nhóm: " + txtGroupName.Text + " không?", "Xóa nhóm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    
                    if(groupBUS.DeleteGroup(txtGroupID.Text))
                        fmGroup_Load(sender, e);
                }
            }
        }
       

        
    }
}
