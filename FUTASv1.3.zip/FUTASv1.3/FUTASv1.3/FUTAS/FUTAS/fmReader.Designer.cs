﻿namespace FUTAS
{
    partial class fmReader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbReaderID = new System.Windows.Forms.Label();
            this.dtgReader = new System.Windows.Forms.DataGridView();
            this.ReaderID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReaderIP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReaderPass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cblReaderStatus = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtReaderID = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtReaderIP = new System.Windows.Forms.TextBox();
            this.lbReaderIP = new System.Windows.Forms.Label();
            this.txtRePass = new System.Windows.Forms.TextBox();
            this.lbRePass = new System.Windows.Forms.Label();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.lbPass = new System.Windows.Forms.Label();
            this.btnChangePass = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtgReader)).BeginInit();
            this.SuspendLayout();
            // 
            // lbReaderID
            // 
            this.lbReaderID.AutoSize = true;
            this.lbReaderID.Location = new System.Drawing.Point(15, 18);
            this.lbReaderID.Name = "lbReaderID";
            this.lbReaderID.Size = new System.Drawing.Size(69, 13);
            this.lbReaderID.TabIndex = 0;
            this.lbReaderID.Text = "Mã đầu đọc:";
            // 
            // dtgReader
            // 
            this.dtgReader.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgReader.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ReaderID,
            this.ReaderIP,
            this.ReaderPass,
            this.cblReaderStatus});
            this.dtgReader.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dtgReader.Location = new System.Drawing.Point(0, 168);
            this.dtgReader.Name = "dtgReader";
            this.dtgReader.ReadOnly = true;
            this.dtgReader.Size = new System.Drawing.Size(664, 182);
            this.dtgReader.TabIndex = 1;
            this.dtgReader.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgReader_RowEnter);
            // 
            // ReaderID
            // 
            this.ReaderID.DataPropertyName = "ReaderID";
            this.ReaderID.HeaderText = "Mã đầu đọc";
            this.ReaderID.Name = "ReaderID";
            this.ReaderID.ReadOnly = true;
            // 
            // ReaderIP
            // 
            this.ReaderIP.DataPropertyName = "ReaderIP";
            this.ReaderIP.HeaderText = "Địa chỉ IP";
            this.ReaderIP.Name = "ReaderIP";
            this.ReaderIP.ReadOnly = true;
            // 
            // ReaderPass
            // 
            this.ReaderPass.DataPropertyName = "ReaderPass";
            this.ReaderPass.HeaderText = "Mật khẩu";
            this.ReaderPass.Name = "ReaderPass";
            this.ReaderPass.ReadOnly = true;
            this.ReaderPass.Visible = false;
            // 
            // cblReaderStatus
            // 
            this.cblReaderStatus.DataPropertyName = "ReaderStatus";
            this.cblReaderStatus.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.cblReaderStatus.HeaderText = "Trạng thái";
            this.cblReaderStatus.Name = "cblReaderStatus";
            this.cblReaderStatus.ReadOnly = true;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(19, 101);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(90, 38);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtReaderID
            // 
            this.txtReaderID.Location = new System.Drawing.Point(91, 14);
            this.txtReaderID.Name = "txtReaderID";
            this.txtReaderID.ReadOnly = true;
            this.txtReaderID.Size = new System.Drawing.Size(100, 20);
            this.txtReaderID.TabIndex = 4;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(147, 101);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(90, 38);
            this.btnUpdate.TabIndex = 5;
            this.btnUpdate.Text = "Sửa";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(543, 101);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(90, 38);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(411, 101);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 38);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Lưu";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(280, 101);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(90, 38);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.Text = "Xóa";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtReaderIP
            // 
            this.txtReaderIP.Location = new System.Drawing.Point(91, 54);
            this.txtReaderIP.Name = "txtReaderIP";
            this.txtReaderIP.Size = new System.Drawing.Size(171, 20);
            this.txtReaderIP.TabIndex = 10;
            // 
            // lbReaderIP
            // 
            this.lbReaderIP.AutoSize = true;
            this.lbReaderIP.Location = new System.Drawing.Point(15, 58);
            this.lbReaderIP.Name = "lbReaderIP";
            this.lbReaderIP.Size = new System.Drawing.Size(56, 13);
            this.lbReaderIP.TabIndex = 9;
            this.lbReaderIP.Text = "Địa chỉ IP:";
            // 
            // txtRePass
            // 
            this.txtRePass.Location = new System.Drawing.Point(391, 54);
            this.txtRePass.Name = "txtRePass";
            this.txtRePass.Size = new System.Drawing.Size(162, 20);
            this.txtRePass.TabIndex = 12;
            this.txtRePass.UseSystemPasswordChar = true;
            // 
            // lbRePass
            // 
            this.lbRePass.AutoSize = true;
            this.lbRePass.Location = new System.Drawing.Point(289, 57);
            this.lbRePass.Name = "lbRePass";
            this.lbRePass.Size = new System.Drawing.Size(96, 13);
            this.lbRePass.TabIndex = 11;
            this.lbRePass.Text = "Nhập lại mật khẩu:";
            // 
            // txtPass
            // 
            this.txtPass.Location = new System.Drawing.Point(391, 14);
            this.txtPass.Name = "txtPass";
            this.txtPass.Size = new System.Drawing.Size(162, 20);
            this.txtPass.TabIndex = 14;
            this.txtPass.UseSystemPasswordChar = true;
            // 
            // lbPass
            // 
            this.lbPass.AutoSize = true;
            this.lbPass.Location = new System.Drawing.Point(289, 18);
            this.lbPass.Name = "lbPass";
            this.lbPass.Size = new System.Drawing.Size(55, 13);
            this.lbPass.TabIndex = 13;
            this.lbPass.Text = "Mật khẩu:";
            // 
            // btnChangePass
            // 
            this.btnChangePass.Location = new System.Drawing.Point(559, 14);
            this.btnChangePass.Name = "btnChangePass";
            this.btnChangePass.Size = new System.Drawing.Size(74, 20);
            this.btnChangePass.TabIndex = 15;
            this.btnChangePass.Text = "Đổi pass";
            this.btnChangePass.UseVisualStyleBackColor = true;
            this.btnChangePass.Click += new System.EventHandler(this.btnChangePass_Click);
            // 
            // fmReader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 350);
            this.Controls.Add(this.btnChangePass);
            this.Controls.Add(this.txtPass);
            this.Controls.Add(this.lbPass);
            this.Controls.Add(this.txtRePass);
            this.Controls.Add(this.lbRePass);
            this.Controls.Add(this.txtReaderIP);
            this.Controls.Add(this.lbReaderIP);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.txtReaderID);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dtgReader);
            this.Controls.Add(this.lbReaderID);
            this.MaximizeBox = false;
            this.Name = "fmReader";
            this.Text = "Quản lý đầu đọc";
            this.Load += new System.EventHandler(this.fmReader_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgReader)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbReaderID;
        private System.Windows.Forms.DataGridView dtgReader;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtReaderID;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtReaderIP;
        private System.Windows.Forms.Label lbReaderIP;
        private System.Windows.Forms.TextBox txtRePass;
        private System.Windows.Forms.Label lbRePass;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.Label lbPass;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReaderID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReaderIP;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReaderPass;
        private System.Windows.Forms.DataGridViewComboBoxColumn cblReaderStatus;
        private System.Windows.Forms.Button btnChangePass;
    }
}