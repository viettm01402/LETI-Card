﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Threading;
using System.Management;
using System.IO.Ports;
using System.Data.SqlClient;
using FUTAS.DataAccess;
using FUTAS.BusinessLogic;

namespace FUTAS
{
    public partial class fmMain : Form
    {
        System.Net.Sockets.TcpClient clientSocket = new System.Net.Sockets.TcpClient();
        NetworkStream serverStream = default(NetworkStream);
        Thread ethThread;
        ConnectData conndata = new ConnectData();
        private ReadcardBUS rcBUS = new ReadcardBUS();
        public static string ID = null;
        enum ConType : int
        {
            NONE,
            ETHERNET_TYPE
        };
        int connection_type = (int)ConType.NONE;
        //properties
        fmGroup fmg = null;
        fmOT fmot = null;
        fmOTDistribution fmod = null;
        fmReader fmr = null;
        fmGroupDist fmgd = null;
        fmEmployee fme = null;
        public fmMain()
        {
            InitializeComponent();
        }

        private void fmMain_Load(object sender, EventArgs e)
        {

        }

        private void quảnLýBộPhậnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fmg == null || fmg.IsDisposed)
                fmg = new fmGroup();
            fmg.Show();
        }

        
        private void itemOLOT_Click(object sender, EventArgs e)
        {
            if(fmot == null || fmot.IsDisposed)
                fmot = new fmOT();
            fmot.Show();
        }

        private void quảnLýcaLàmViệcToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fmShift fms = new fmShift();
            fms.Show(); 
        }

        private void quảnLýnhânViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fme == null || fme.IsDisposed)
                fme = new fmEmployee();
            fme.Show();
        }

        private void itemOTDistribution_Click(object sender, EventArgs e)
        {
            if(fmod == null || fmod.IsDisposed)
                fmod = new fmOTDistribution();
            fmod.Show();
        }

        private void itemReader_Click(object sender, EventArgs e)
        {
            if (fmr == null || fmr.IsDisposed)
                fmr = new fmReader();
            fmr.Show();
        }

        private void itemShiftDistribution_Click(object sender, EventArgs e)
        {
            if (fmgd == null || fmgd.IsDisposed)
                fmgd = new fmGroupDist();
            fmgd.Show();
        }

        private void ConnectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (comPort.IsOpen)
                {
                    comPort.Write("D");
                    comPort.Close();
                }

                clientSocket = new System.Net.Sockets.TcpClient();
                clientSocket.Connect("192.168.1.88", 6868);

                if (clientSocket.Connected)
                {
                    MessageBox.Show("Connect successful!");
                    ethThread = new Thread(getEthMessage);
                    ethThread.Start();

                    connection_type = (int)ConType.ETHERNET_TYPE;

                    ConnectToolStripMenuItem.Checked = true;
                    rcBUS.deleteData();

                }
                else
                {
                    MessageBox.Show("Can't connect!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        private void getEthMessage()
        {
            while (true)
            {
                try
                {
                    serverStream = clientSocket.GetStream();
                    int buffSize = 0;
                    byte[] inStream = new byte[10025];
                    buffSize = clientSocket.ReceiveBufferSize;
                    serverStream.Read(inStream, 0, buffSize);
                    string returndata = System.Text.Encoding.ASCII.GetString(inStream);
                    char[] temp = returndata.ToCharArray();

                    if (temp[0] == 'T')
                    {
                        ID = returndata.Substring(1, 8);
                    }

                    ID_Handle();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }



        string comData = "";

        void getComData(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try
            {
                string text = comPort.ReadExisting();

                byte[] bytes = Encoding.Unicode.GetBytes(text);

                if (bytes.Length != 0)
                {
                    comData += text;
                    if (comData.Length >= 9)
                    {
                        byte[] temp = Encoding.Unicode.GetBytes(comData);
                        if (temp[0] == 'T')
                        {
                            ID = comData.Substring(1, 8);
                            ID_Handle();

                            comData = "";
                        }
                        else
                        {
                            comData = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ID_Handle()
        {
            if (this.InvokeRequired)
                this.Invoke(new MethodInvoker(ID_Handle));
            else
            {
                //Add info card to database
                rcBUS.addInfoCard();
            }
        }

        int count = 0;
        private void timer_Tick(object sender, EventArgs e)
        {
            if (count == 50)
            {
                rcBUS.updateData();
                rcBUS.deleteData();
                count = 0;
            }
            if (count % 5 == 0)
            {

            }
            count++;

        }

       

        
    }
}
