﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FUTAS.BusinessObject
{
    class OTDistribution
    {
        public int ODID { get; set; }
        public DateTime OTDate { get; set; }
        public int EmpID { get; set; }
        public int OtID { get; set; }
        public int OTStatus { get; set; }
    }
}
