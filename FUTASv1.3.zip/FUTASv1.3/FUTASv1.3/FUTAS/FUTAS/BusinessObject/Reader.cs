﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FUTAS.BusinessObject
{
    class Reader
    {
        public int ReaderID { get; set; }
        public string ReaderIP { get; set; }
        public string ReaderPass { get; set; }
        public int ReaderStatus { get; set; }
    }
}
