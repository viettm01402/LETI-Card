﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FUTAS.BusinessObject
{
    class OT
    {
        public int OtID { get; set; }
        public string OtName { get; set; }
        public DateTime OtStartTime { get; set; }
        public DateTime OtEndTime { get; set; }
        public float OtRate { get; set; }

    }
}
