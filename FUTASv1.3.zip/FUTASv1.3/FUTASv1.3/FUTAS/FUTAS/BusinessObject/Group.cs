﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FUTAS.BusinessObject
{
    class Group
    {
        public int GroupID { get; set; }
        public string GroupName { get; set; }
        public string Department { get; set; }
    }
}
