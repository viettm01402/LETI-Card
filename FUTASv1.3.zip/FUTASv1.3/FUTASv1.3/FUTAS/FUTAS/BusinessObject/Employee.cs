﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FUTAS.BusinessObject
{
    class Employee
    {
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public DateTime DOB { get; set; }
        public int Gender { get; set; }
        public string CardID { get; set; }
        public int GroupID { get; set; }
        public DateTime JoinDate { get; set; }
        public float BaseSalary { get; set; }
        public int TotalDayOnLeave { get; set; }

    }
}
