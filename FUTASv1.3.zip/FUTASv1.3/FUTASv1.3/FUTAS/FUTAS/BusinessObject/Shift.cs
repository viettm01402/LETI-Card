﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FUTAS.BusinessObject
{
    class Shift
    {
        public int ShiftID { get; set; }
        public string ShiftName { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string ShiftType { get; set; }
        public string ShiftDescription { get; set; }
        public float Rate { get; set; }
    }
}
