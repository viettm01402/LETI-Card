﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FUTAS.BusinessObject
{
    class GroupDist
    {
        public int GRID { get; set; }
        public int GroupID { get; set; }
        public string GroupName { get; set; }
        public int ShiftID { get; set; }
        public string ShiftName { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
    }
}
