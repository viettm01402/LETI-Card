﻿namespace FUTAS
{
    partial class fmOTDistribution
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbODID = new System.Windows.Forms.Label();
            this.txtODID = new System.Windows.Forms.TextBox();
            this.lbOTDate = new System.Windows.Forms.Label();
            this.dtpOTDate = new System.Windows.Forms.DateTimePicker();
            this.lbEmpID = new System.Windows.Forms.Label();
            this.txtEmpID = new System.Windows.Forms.TextBox();
            this.lbOTType = new System.Windows.Forms.Label();
            this.cboOTType = new System.Windows.Forms.ComboBox();
            this.cboOTStatus = new System.Windows.Forms.ComboBox();
            this.lbOTStatus = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.dtgOTDistribution = new System.Windows.Forms.DataGridView();
            this.ODID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OTDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cblOTType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.EmpID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmpName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CardID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cblOTStatus = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.btnAddOT = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtgOTDistribution)).BeginInit();
            this.SuspendLayout();
            // 
            // lbODID
            // 
            this.lbODID.AutoSize = true;
            this.lbODID.Location = new System.Drawing.Point(13, 13);
            this.lbODID.Name = "lbODID";
            this.lbODID.Size = new System.Drawing.Size(67, 13);
            this.lbODID.TabIndex = 0;
            this.lbODID.Text = "Mã phân ca:";
            // 
            // txtODID
            // 
            this.txtODID.Location = new System.Drawing.Point(86, 10);
            this.txtODID.Name = "txtODID";
            this.txtODID.ReadOnly = true;
            this.txtODID.Size = new System.Drawing.Size(77, 20);
            this.txtODID.TabIndex = 1;
            // 
            // lbOTDate
            // 
            this.lbOTDate.AutoSize = true;
            this.lbOTDate.Location = new System.Drawing.Point(13, 84);
            this.lbOTDate.Name = "lbOTDate";
            this.lbOTDate.Size = new System.Drawing.Size(53, 13);
            this.lbOTDate.TabIndex = 0;
            this.lbOTDate.Text = "Ngày OT:";
            // 
            // dtpOTDate
            // 
            this.dtpOTDate.Location = new System.Drawing.Point(85, 81);
            this.dtpOTDate.Name = "dtpOTDate";
            this.dtpOTDate.Size = new System.Drawing.Size(221, 20);
            this.dtpOTDate.TabIndex = 2;
            // 
            // lbEmpID
            // 
            this.lbEmpID.AutoSize = true;
            this.lbEmpID.Location = new System.Drawing.Point(440, 13);
            this.lbEmpID.Name = "lbEmpID";
            this.lbEmpID.Size = new System.Drawing.Size(75, 13);
            this.lbEmpID.TabIndex = 4;
            this.lbEmpID.Text = "Mã nhân viên:";
            // 
            // txtEmpID
            // 
            this.txtEmpID.Location = new System.Drawing.Point(513, 10);
            this.txtEmpID.Name = "txtEmpID";
            this.txtEmpID.Size = new System.Drawing.Size(193, 20);
            this.txtEmpID.TabIndex = 5;
            this.txtEmpID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEmpID_KeyPress);
            // 
            // lbOTType
            // 
            this.lbOTType.AutoSize = true;
            this.lbOTType.Location = new System.Drawing.Point(13, 48);
            this.lbOTType.Name = "lbOTType";
            this.lbOTType.Size = new System.Drawing.Size(45, 13);
            this.lbOTType.TabIndex = 6;
            this.lbOTType.Text = "Loại OT";
            // 
            // cboOTType
            // 
            this.cboOTType.FormattingEnabled = true;
            this.cboOTType.Location = new System.Drawing.Point(86, 45);
            this.cboOTType.Name = "cboOTType";
            this.cboOTType.Size = new System.Drawing.Size(162, 21);
            this.cboOTType.TabIndex = 7;
            // 
            // cboOTStatus
            // 
            this.cboOTStatus.FormattingEnabled = true;
            this.cboOTStatus.Location = new System.Drawing.Point(513, 50);
            this.cboOTStatus.Name = "cboOTStatus";
            this.cboOTStatus.Size = new System.Drawing.Size(193, 21);
            this.cboOTStatus.TabIndex = 9;
            // 
            // lbOTStatus
            // 
            this.lbOTStatus.AutoSize = true;
            this.lbOTStatus.Location = new System.Drawing.Point(440, 53);
            this.lbOTStatus.Name = "lbOTStatus";
            this.lbOTStatus.Size = new System.Drawing.Size(58, 13);
            this.lbOTStatus.TabIndex = 8;
            this.lbOTStatus.Text = "Tình trạng:";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(16, 131);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(78, 38);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(159, 131);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(78, 38);
            this.btnUpdate.TabIndex = 11;
            this.btnUpdate.Text = "Sửa";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDel
            // 
            this.btnDel.Location = new System.Drawing.Point(305, 131);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(78, 38);
            this.btnDel.TabIndex = 12;
            this.btnDel.Text = "Xóa";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(454, 131);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(78, 38);
            this.btnSave.TabIndex = 13;
            this.btnSave.Text = "Lưu";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(588, 131);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(78, 38);
            this.btnCancel.TabIndex = 14;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // dtgOTDistribution
            // 
            this.dtgOTDistribution.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgOTDistribution.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ODID,
            this.OTDate,
            this.cblOTType,
            this.EmpID,
            this.EmpName,
            this.CardID,
            this.cblOTStatus});
            this.dtgOTDistribution.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dtgOTDistribution.Location = new System.Drawing.Point(0, 190);
            this.dtgOTDistribution.Name = "dtgOTDistribution";
            this.dtgOTDistribution.Size = new System.Drawing.Size(796, 165);
            this.dtgOTDistribution.TabIndex = 15;
            this.dtgOTDistribution.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgOTDistribution_RowEnter);
            // 
            // ODID
            // 
            this.ODID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.ODID.DataPropertyName = "ODID";
            this.ODID.HeaderText = "Mã phân ca";
            this.ODID.Name = "ODID";
            this.ODID.ReadOnly = true;
            this.ODID.Width = 71;
            // 
            // OTDate
            // 
            this.OTDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.OTDate.DataPropertyName = "OTDate";
            this.OTDate.HeaderText = "Ngày OT";
            this.OTDate.Name = "OTDate";
            this.OTDate.ReadOnly = true;
            this.OTDate.Width = 70;
            // 
            // cblOTType
            // 
            this.cblOTType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.cblOTType.DataPropertyName = "OtID";
            this.cblOTType.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.cblOTType.HeaderText = "Ca OT";
            this.cblOTType.Name = "cblOTType";
            this.cblOTType.ReadOnly = true;
            this.cblOTType.Width = 40;
            // 
            // EmpID
            // 
            this.EmpID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.EmpID.DataPropertyName = "EmpID";
            this.EmpID.HeaderText = "Mã nhân viên";
            this.EmpID.Name = "EmpID";
            this.EmpID.ReadOnly = true;
            this.EmpID.Width = 89;
            // 
            // EmpName
            // 
            this.EmpName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.EmpName.DataPropertyName = "EmpName";
            this.EmpName.HeaderText = "Tên nhân viên";
            this.EmpName.Name = "EmpName";
            this.EmpName.ReadOnly = true;
            this.EmpName.Width = 93;
            // 
            // CardID
            // 
            this.CardID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.CardID.DataPropertyName = "CardID";
            this.CardID.HeaderText = "Mã thẻ nhân viên";
            this.CardID.Name = "CardID";
            this.CardID.ReadOnly = true;
            this.CardID.Width = 88;
            // 
            // cblOTStatus
            // 
            this.cblOTStatus.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.cblOTStatus.DataPropertyName = "OTStatus";
            this.cblOTStatus.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.cblOTStatus.HeaderText = "Tình trạng";
            this.cblOTStatus.Name = "cblOTStatus";
            this.cblOTStatus.ReadOnly = true;
            this.cblOTStatus.Width = 55;
            // 
            // btnAddOT
            // 
            this.btnAddOT.Location = new System.Drawing.Point(254, 42);
            this.btnAddOT.Name = "btnAddOT";
            this.btnAddOT.Size = new System.Drawing.Size(52, 24);
            this.btnAddOT.TabIndex = 16;
            this.btnAddOT.Text = "Thêm";
            this.btnAddOT.UseVisualStyleBackColor = true;
            this.btnAddOT.Click += new System.EventHandler(this.btnAddOT_Click);
            // 
            // fmOTDistribution
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(796, 355);
            this.Controls.Add(this.btnAddOT);
            this.Controls.Add(this.dtgOTDistribution);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.cboOTStatus);
            this.Controls.Add(this.lbOTStatus);
            this.Controls.Add(this.cboOTType);
            this.Controls.Add(this.lbOTType);
            this.Controls.Add(this.txtEmpID);
            this.Controls.Add(this.lbEmpID);
            this.Controls.Add(this.dtpOTDate);
            this.Controls.Add(this.lbOTDate);
            this.Controls.Add(this.txtODID);
            this.Controls.Add(this.lbODID);
            this.MaximizeBox = false;
            this.Name = "fmOTDistribution";
            this.Text = "Phân ca OT";
            this.Load += new System.EventHandler(this.fmOTDistribution_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgOTDistribution)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbODID;
        private System.Windows.Forms.TextBox txtODID;
        private System.Windows.Forms.Label lbOTDate;
        private System.Windows.Forms.DateTimePicker dtpOTDate;
        private System.Windows.Forms.Label lbEmpID;
        private System.Windows.Forms.TextBox txtEmpID;
        private System.Windows.Forms.Label lbOTType;
        private System.Windows.Forms.ComboBox cboOTType;
        private System.Windows.Forms.ComboBox cboOTStatus;
        private System.Windows.Forms.Label lbOTStatus;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DataGridView dtgOTDistribution;
        private System.Windows.Forms.Button btnAddOT;
        private System.Windows.Forms.DataGridViewTextBoxColumn ODID;
        private System.Windows.Forms.DataGridViewTextBoxColumn OTDate;
        private System.Windows.Forms.DataGridViewComboBoxColumn cblOTType;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmpID;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmpName;
        private System.Windows.Forms.DataGridViewTextBoxColumn CardID;
        private System.Windows.Forms.DataGridViewComboBoxColumn cblOTStatus;
    }
}