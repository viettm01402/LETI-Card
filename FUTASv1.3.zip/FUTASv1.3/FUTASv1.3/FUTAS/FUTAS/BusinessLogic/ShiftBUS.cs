﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using FUTAS.DataAccess;
using FUTAS.BusinessObject;
using FUTAS.BusinessLogic;

namespace FUTAS.BusinessLogic
{
    class ShiftBUS
    {
        ConnectData connData = new ConnectData();
        //Lay data tu tbShift
        public DataTable getShift()
        {
            string sql = "SELECT * FROM tblShift";
            return connData.GetDataTable(sql);
        }
        //Them Shift
        public bool AddShift(Shift sh)
        {
            if (validateShift(sh))
            {
                string sql = string.Format("INSERT INTO tblShift (ShiftName, StartTime, EndTime, ShiftType, ShiftDescription, Rate) "
                    + "VALUES (N'{0}','{1}','{2}',N'{3}',N'{4}','{5}')",
                    sh.ShiftName, sh.StartTime, sh.EndTime, sh.ShiftType, sh.ShiftDescription, sh.Rate);
                if (connData.ExecuteQuery(sql))
                {
                    MessageBox.Show("Add new shift successfull !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }
            }
            return false;
        }
        public bool CheckExist(string shiftID)
        {
            if (connData.CheckExistValue("tblShift", "ShiftID", shiftID))
                return true;
            return false;
        }
        //Edit Shift
        public bool EditShift(Shift sh) 
        {
            if (validateShift(sh))
            {
                string sql = string.Format("UPDATE tblShift SET ShiftName =N'{0}', StartTime ='{1}', EndTime ='{2}', ShiftType =N'{3}', ShiftDescription =N'{4}', Rate ='{5}' WHERE ShiftID ='{6}' ",
                    sh.ShiftName, sh.StartTime, sh.EndTime, sh.ShiftType, sh.ShiftDescription, sh.Rate, sh.ShiftID);
                if (connData.ExecuteQuery(sql))
                {
                    MessageBox.Show("Edit shift successfull !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }
            }
            return false;
        }
        //Xoa 1 shift
        public bool deleteShift(string shiftID)
        { 
            //xoa bang grouprecords truoc sau do xoa bang shift
            string sql = "DELETE FROM tblGroupRecord WHERE ShiftID in ('" +shiftID+ "') "
                + "DELETE FROM tblShift WHERE ShiftID in ('" + shiftID + "')";
            if (connData.ExecuteQuery(sql))
            {
                MessageBox.Show("Delete shift successfull !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }
            return false;
        }
        
        //Kiem tra truoc khi luu database
        public bool validateShift(Shift sh)
        {
            if (sh.ShiftName.Equals(""))
            {
                MessageBox.Show("Shift name is not valid");
                return false;
            }
            else if (sh.StartTime.ToString("hh:mm:ss tt").Equals("12:00:01 AM"))
            {
                MessageBox.Show("Start time is not valid");
                return false;
            }
            else if (sh.EndTime.ToString("hh:mm:ss tt").Equals("12:00:01 AM"))
            {
                MessageBox.Show("End time is not valid");
                return false;
            }
            else if (sh.ShiftType.Equals(""))
            {
                MessageBox.Show("Shift type is not valid");
                return false;
            }
            else if (sh.Rate.Equals("") || sh.Rate.Equals(0))
            {
                MessageBox.Show("Rate is not valid");
                return false;
            }

            return true;
        }
        public string nextID()
        {
            return Utilitiescs.NextID(connData.GetLastID("tblShift", "ShiftID"));
        }
    }
}
