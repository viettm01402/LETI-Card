﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;

using FUTAS.DataAccess;
using FUTAS.BusinessObject;

namespace FUTAS.BusinessLogic
{
    class OTDisBUS
    {
        ConnectData connData = new ConnectData();
        //GET ALL OT Distribution
        public DataTable GetAllOD()
        {
            string sql = "SELECT tblOTDistribution.ODID AS ODID, tblOTDistribution.OTDate AS OTDate, "
                       + "tblOTDistribution.OtID AS OtID, dbo.tblEmployee.EmpID AS EmpID, tblEmployee.EmpName AS EmpName, tblEmployee.CardID AS CardID, tblOTDistribution.OTStatus AS OTStatus "
                       + "FROM tblEmployee INNER JOIN tblOTDistribution ON tblEmployee.EmpID = tblOTDistribution.EmpID "
                       + "ORDER BY tblOTDistribution.ODID ASC";
            return connData.GetDataTable(sql);

        }
        //Get list of tblOT
        public DataTable GetAllOT()
        {
            string sql = "SELECT OtID,OtName,OtRate FROM tblOT";
            return connData.GetDataTable(sql);
        }
        //Get ODStatus
        public DataTable GetODStatus()
        {
            string sql = "SELECT DISTINCT OTStatus, "
                        + "NameOS = CASE OTStatus WHEN 0 THEN N'Chưa thực hiện' "
                        + "WHEN 1 THEN N'Đã thực hiện' END FROM tblOTDistribution";
            return connData.GetDataTable(sql);
        }
        //Add 1 OTD
        public bool addOTD(OTDistribution otd) 
        {
            if (ValidateOTD(otd))
            {
                String sql = string.Format("INSERT INTO tblOTDistribution (OTDate,EmpID,OtID,OTStatus) "
                   + "VALUES ('{0}',{1},{2},{3})", otd.OTDate, otd.EmpID,otd.OtID,otd.OTStatus);
                if (connData.ExecuteQuery(sql))
                {
                    MessageBox.Show("Phân ca thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }
            }
            return false;
        }
        //Update 1 ca OT
        public bool UpdateOTD(OTDistribution otd)
        {
            if (ValidateOTD(otd))
            {
                String sql = string.Format("UPDATE tblOTDistribution SET OtDate = '{0}',EmpID = {1},OtID = {2}, OTStatus = {3} WHERE ODID = {4}", otd.OTDate, otd.EmpID, otd.OtID, otd.OTStatus, otd.ODID);
                if (connData.ExecuteQuery(sql))
                {
                    MessageBox.Show("Sửa phân ca OT thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }

            }
            return false;
        }
        //Check exist ID
        public bool CheckExistID(string ODID)
        {
            if (connData.CheckExistValue("tblOTDistribution", "ODID", ODID))
                return true;
            return false;
        }
        //Check Exist OTD
        public bool checkexistOTD(OTDistribution otd)
        {
            String sql = string.Format("SELECT * FROM tblOTDistribution WHERE OTDate = '{0}' AND EmpID = {1} AND OtID = {2}",otd.OTDate,otd.EmpID,otd.OtID);
            if(connData.GetDataTable(sql).Rows.Count > 0)
                return true;
            return false;

        }
        //Delete 1 ca OT
        public bool DeleteOTD(string ODID)
        {
            int tempID = 0;
            int.TryParse(ODID, out tempID);
            string sql = "DELETE FROM tblOTDistribution WHERE ODID = " + tempID;
            if (connData.ExecuteQuery(sql))
            {
                MessageBox.Show("Xóa phân ca thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }
            return false;
        }
        //Validate OTDistribution
        public bool ValidateOTD(OTDistribution otd) 
        {
           if(connData.CheckExistValue("tblEmployee","EmpID",otd.EmpID.ToString()) == false)
           {
               MessageBox.Show("Nhân viên này không tồn tại","Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
               return false;
           }
           if (otd.OTDate.Year < 2012) 
           {
               MessageBox.Show("Ngày đăng ký OT không hợp lệ", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
               return false;
           }
           
           return true;
        }
        public string NextID()
        {
            return Utilitiescs.NextID(connData.GetLastID("tblOTDistribution", "ODID"));
        }
    }
}
