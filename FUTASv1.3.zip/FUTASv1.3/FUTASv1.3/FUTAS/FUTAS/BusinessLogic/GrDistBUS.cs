﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;

using FUTAS.DataAccess;
using FUTAS.BusinessObject;
using FUTAS.BusinessLogic;

namespace FUTAS.BusinessLogic
{
    class GrDistBUS
    {
        ConnectData connData = new ConnectData();
        //Lay data tu tbGroupRecprds
        public DataTable getGrDist()
        {
            string sql = "SELECT GRID, GroupID, tblGroupRecord.ShiftID, tblShift.StartTime, tblShift.EndTime FROM tblGroupRecord INNER JOIN tblShift ON tblGroupRecord.ShiftID = tblShift.ShiftID";
            return connData.GetDataTable(sql);
        }
        //Them GroupDist
        public bool AddGroupDist(GroupDist grd)
        {
            if (validateGroupDist(grd))
            {
                string sql = string.Format("INSERT INTO tblGroupRecord (GroupID, ShiftID) "
                    + "VALUES ('{0}','{1}')",
                    grd.GroupID, grd.ShiftID);
                if (connData.ExecuteQuery(sql))
                {
                    MessageBox.Show("Phân ca thành công !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }
            }
            return false;
        }
        public bool CheckExist(string GroupID)
        {
            if (connData.CheckExistValue("tblGroupRecord", "GroupID", GroupID))
                return true;
            return false;
        }
        //Edit GroupDist
        public bool EditGroupDist(GroupDist grd)
        {
            if (validateGroupDist(grd))
            {
                string sql = string.Format("UPDATE tblGroupRecord SET GroupID ='{0}', ShiftID ='{1}' WHERE GroupID = '{2}' ",
                    grd.GroupID, grd.ShiftID, grd.GroupID);
                if (connData.ExecuteQuery(sql))
                {
                    MessageBox.Show("Sửa phân ca thành công !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }
            }
            return false;
        }
        //Xoa 1 record
        public bool deleteGroupDist(string GroupID)
        {
            //xoa bang grouprecords truoc sau do xoa bang shift
            string sql = "DELETE FROM tblGroupRecord WHERE GroupID in ('" + GroupID + "') ";
            if (connData.ExecuteQuery(sql))
            {
                MessageBox.Show("Delete shift successfull !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }
            return false;
        }
        //Kiem tra truoc khi luu database
        public bool validateGroupDist(GroupDist grd)
        {
            if (grd.GroupID.Equals(""))
            {
                MessageBox.Show("Xin hãy chọn nhóm cần phân ca làm việc!");
                return false;
            }
            else if (grd.ShiftID.Equals(""))
            {
                MessageBox.Show("Xin hãy chọn ca làm việc muốn phân!");
                return false;
            }
            return true;
        }
        public string nextID()
        {
            if(connData.CheckExistData("tblGroupRecord"))
                return Utilitiescs.NextID(connData.GetLastID("tblGroupRecord", "GRID"));
            return "0";
        }
    }
}
