﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using FUTAS.DataAccess;
using FUTAS.BusinessObject;

namespace FUTAS.BusinessLogic
{
    class EmployeeBUS
    {
        ConnectData connData = new ConnectData();
        //Lấy danh sách nhân viên
        public DataTable GetListEmployee()
        {
            string sql = "SELECT  EmpID, EmpName, DOB, Gender, CardID, GroupID, JoinDate, BaseSalary FROM tblEmployee";
            return connData.GetDataTable(sql);

        }

        //Lấy giới tính 
        public DataTable GetGenderEmployee()
        {
            string sql = "SELECT DISTINCT Gender,"
                        + "NameGT = CASE Gender WHEN 0 THEN 'Nam' "
                        + "WHEN 1 THEN N'Nữ' END FROM tblEmployee";
            return connData.GetDataTable(sql);
        }

        //Them nhan vien
        public bool AddEmp(Employee emp)
        {
            if (CheckInputData(emp))
            {
                string sql = string.Format("INSERT INTO tblEmployee(EmpName, DOB, Gender, CardID, GroupID, JoinDate, BaseSalary,TotalDayOnLeave)"
                + "VALUES(N'{0}','{1}',{2},'{3}','{4}','{5}',{6},{7})", emp.EmpName, emp.DOB, emp.Gender, emp.CardID, emp.GroupID, emp.JoinDate, emp.BaseSalary, emp.TotalDayOnLeave);

                if (connData.ExecuteQuery(sql))
                {
                    MessageBox.Show("Thêm mới thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }
            }
            return false;
        }
        //kiem tra su ton tai cua ID 
        public bool CheckExits(int empid)
        {
            if (connData.CheckExistValue("tblEmployee", "EmpID", empid.ToString()))
                return true;
            return false;
        }

        //Sua nhan vien
        public bool EditEmp(Employee emp)
        {
            if (CheckInputData(emp))
            {
                string sql = string.Format("UPDATE tblEmployee SET EmpName = N'{0}', DOB = '{1}', Gender = {2},  GroupID ={3}, JoinDate ='{4}', BaseSalary = {5},TotalDayOnLeave = {6} WHERE EmpID = {7}",
                emp.EmpName, emp.DOB, emp.Gender, emp.GroupID, emp.JoinDate, emp.BaseSalary, emp.TotalDayOnLeave, emp.EmpID);

                if (connData.ExecuteQuery(sql))
                {
                    MessageBox.Show("Cập nhật thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }
            }
            return false;
        }

        public bool DeleteEmp(string empid)
        {

            string sql = "DELETE FROM tblRecord WHERE EmpID = " + empid
                   + " DELETE FROM tblOTDistribution WHERE EmpID = " + empid
                   + " DELETE FROM tblEmployee WHERE EmpID = " + empid;
            if (connData.ExecuteQuery(sql))
            {
                MessageBox.Show("Đã xóa thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }
            return false;

        }

        //Kiem tra du lieu cardID nhap vao
        public bool checkMatchData(Employee emp)
        {
            string sql = "SELECT TOP 1 CardID FROM tblEmployee WHERE CardID ='" + emp.CardID + "'";

            if (connData.ExecuteQuery(sql))
            {
                MessageBox.Show("Trùng mã thẻ", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return true;
            }
            return false;

        }

        //Kiem tra du lieu dau vao
        public bool CheckInputData(Employee emp)
        {
            if (emp.EmpName.Equals(""))
            {
                MessageBox.Show("Họ tên không hợp lệ.");
                return false;
            }
            else if (emp.DOB.Year < 1953)
            {
                MessageBox.Show("Năm sinh không hợp lệ.");
                return false;
            }
            else if (emp.CardID.Equals(""))
            {
                MessageBox.Show("Mã thẻ không hợp lệ");
                return false;
            }
            else if (emp.JoinDate.Year < 2010)
            {
                MessageBox.Show("Ngày gia nhập không hợp lệ.");
                return false;
            }

            else
                return true;
        }


        public string NextID()
        {
            int IntEmpID;
            int.TryParse(connData.GetLastID("tblEmployee", "EmpID"), out IntEmpID);
            int NextID = IntEmpID + 1;
            return NextID.ToString();
        }

    }
}
