﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;
using System.Text.RegularExpressions;

using FUTAS.DataAccess;
using FUTAS.BusinessObject;
namespace FUTAS.BusinessLogic
{
    class ReaderBUS
    {
        ConnectData connData = new ConnectData();
        //GetAllReader
        public DataTable GetAllReader() 
        {
            String sql = "SELECT ReaderID,ReaderIP,ReaderPass,ReaderStatus FROM tblReader";
            return connData.GetDataTable(sql);
        }
        //Get Reader status
        public DataTable GetReaderStatus() 
        {
            String sql = "SELECT DISTINCT ReaderStatus,NameStatus = CASE ReaderStatus WHEN 0 THEN N'Ngắt kết nối'"
                        + " WHEN 1 THEN N'Đang kết nối' END FROM tblReader";
            return connData.GetDataTable(sql);
        }
        //Add1Reader
        public bool AddReader(Reader r) 
        {
            if (validateReader(r))
            {
                String sql = string.Format("INSERT INTO tblReader(ReaderIP,ReaderPass,ReaderStatus) "
                            + "VALUES ('{0}','{1}',{2})", r.ReaderIP, r.ReaderPass, r.ReaderStatus);
                if (connData.ExecuteQuery(sql))
                {
                    MessageBox.Show("Thêm đầu đọc thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }
            }
            return false;
        }
        //Update Reader
        public bool UpdateReader(Reader r,bool flagchangepass)
        {
            if (validateReader(r))
            {
                String sql = "";
                if(flagchangepass == false)
                    sql = string.Format("UPDATE tblReader SET ReaderIP = '{0}' WHERE ReaderID = {1}", r.ReaderIP, r.ReaderID);
                else
                    sql = string.Format("UPDATE tblReader SET ReaderIP = '{0}', ReaderPass = '{1}' WHERE ReaderID = {2}", r.ReaderIP,r.ReaderPass, r.ReaderID);
                if (connData.ExecuteQuery(sql))
                {
                    MessageBox.Show("Sửa đầu đọc thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }
            }
            return false;
        }
        //Delete reader
        public bool DeleteReader(string readerid) 
        {
            int delID = 0;
            int.TryParse(readerid, out delID);
            String sql = "DELETE FROM tblRecord WHERE ReaderID = " + delID
                + " DELETE FROM tblReader WHERE ReaderID = " + delID;
            if (connData.ExecuteQuery(sql))
            {
                MessageBox.Show("Xóa đầu đọc thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }
            return false;

        }
        //ValidateReader
        public bool validateReader(Reader r) 
        {
            string readerip = r.ReaderIP;
            Regex regex = new Regex(@"^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
            if (regex.IsMatch(readerip) == false)
            {
                MessageBox.Show("Địa chỉ IP phải nhập theo mẫu 111.111.111.111");
                return false;
            }
            if (r.ReaderIP.Equals(""))
            {
                MessageBox.Show("Địa chỉ IP không được để trống");
                return false;
            }
            return true;
        }
        public bool checkReaderID(string rID)
        {
            if (connData.CheckExistValue("tblReader", "ReaderID", rID))
            {
                
                return true;
            }
            return false;
        }
        public bool checkReaderIP(string rIP) 
        {
            if (connData.CheckExistValue("tblReader", "ReaderIP", rIP) == true)
            {
                MessageBox.Show("Đã có đầu đọc này trong danh sách","Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        //NextID
        public string NextID()
        {
            return Utilitiescs.NextID(connData.GetLastID("tblReader", "ReaderID"));
        }
    }
}
