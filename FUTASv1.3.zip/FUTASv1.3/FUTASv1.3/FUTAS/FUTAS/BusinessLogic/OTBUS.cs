﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using FUTAS.DataAccess;
using FUTAS.BusinessObject;
namespace FUTAS.BusinessLogic
{
    class OTBUS
    {
        ConnectData connData = new ConnectData();
        //Get list of tblOT
        public DataTable GetAllOT() 
        {
            string sql = "SELECT OtID,OtName,OtStartTime,OtEndTime,OtRate FROM tblOT";
            return connData.GetDataTable(sql);
        }
        //Add 1 OT
        public bool AddOT(OT ot)
        {
            if (ValidateOT(ot))
            {
                String sql = string.Format("INSERT INTO tblOT (OtName,OtStartTime,OtEndTime,OtRate) "
                   + "VALUES (N'{0}',{1},{2},{3})", ot.OtName,ot.OtStartTime,ot.OtEndTime,ot.OtRate);
                if (connData.ExecuteQuery(sql))
                {
                    MessageBox.Show("Thêm ca OT thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }
            }
            return false;
        }
        //Check exist ID
        public bool CheckExistID(string otID)
        {
            if (connData.CheckExistValue("tblOT", "OtID", otID))
                return true;
            return false;
        }
        //Update 1 ca OT
        public bool UpdateOT(OT ot)
        {
            if (ValidateOT(ot))
            {
                String sql = string.Format("UPDATE tblOT SET OtName = N'{0}',OtStartTime = '{1}',OtEndTime = '{2}', OtRate = {3} WHERE OtID = {4}", ot.OtName,ot.OtStartTime,ot.OtEndTime, ot.OtRate, ot.OtID);
                if (connData.ExecuteQuery(sql))
                {
                    MessageBox.Show("Sửa ca OT thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }

            }
            return false;
        }
        //Delete 1 ca OT
        public bool DeleteOT(string otID)
        {
            int tempID = 0;
            int.TryParse(otID, out tempID);
            string sql = "DELETE FROM tblOTDistribution WHERE OtID = " + tempID
                  + " DELETE FROM tblOT WHERE OtID = " + tempID;
            if (connData.ExecuteQuery(sql))
            {
                MessageBox.Show("Xóa ca OT thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }
            return false;
        }
        public bool ValidateOT(OT ot)
        {
            if (ot.OtName.Equals(""))
            {
                MessageBox.Show("Tên ca không được để trống","Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return false;
            }
            if (ot.OtRate.Equals(""))
            {
                MessageBox.Show("Hệ số không được để trống", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            int compare = DateTime.Compare(ot.OtStartTime, ot.OtEndTime);
            if (compare == 1 || compare == 0)
            {
                MessageBox.Show("Giờ kết thúc phải lớn hơn giờ bắt đầu", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        public string NextID()
        {
            return Utilitiescs.NextID(connData.GetLastID("tblOT","OtID"));
        }
    }
}
