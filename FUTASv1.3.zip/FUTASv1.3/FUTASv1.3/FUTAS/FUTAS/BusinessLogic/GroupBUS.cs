﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;

using FUTAS.DataAccess;
using FUTAS.BusinessObject;
namespace FUTAS.BusinessLogic
{
    class GroupBUS
    {
        ConnectData connData = new ConnectData();
        //Get list of tblGroup
        public DataTable GetAllGroup()
        {
            string sql = "SELECT GroupID,GroupName,Department FROM tblGroup";
            return connData.GetDataTable(sql);
        }
        //Add 1 Group
        public bool AddGroup(Group g) 
        {
            if (ValidateGroup(g))
            {
                String sql = string.Format("INSERT INTO tblGroup (GroupName,Department) "
                   + "VALUES (N'{0}',N'{1}')", g.GroupName, g.Department);
                if (connData.ExecuteQuery(sql))
                {
                    MessageBox.Show("Thêm nhóm thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }
              
            }
            return false;
        }
        //Check exist ID
        public bool CheckExistID(string groupID) 
        {
            if (connData.CheckExistValue("tblGroup", "GroupID", groupID))
                return true;
            return false;
        }
        //Update 1 Group
        public bool UpdateGroup(Group g)
        {
            if (ValidateGroup(g))
            {
                String sql = string.Format("UPDATE tblGroup SET GroupName = N'{0}', Department = N'{1}' WHERE GroupID = {2}", g.GroupName, g.Department,g.GroupID);
                if (connData.ExecuteQuery(sql))
                {
                    MessageBox.Show("Sửa nhóm thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }

            }
            return false;
        }
        //Delete 1 group
        public bool DeleteGroup(string groupID) 
        {
            int tempID = 0;
            int.TryParse(groupID, out tempID);
            string sql = "DELETE FROM tblGroupRecord WHERE GroupID = " + tempID
                  + " UPDATE tblEmployee SET GroupID = 1 WHERE GroupID = " + tempID
                  + " DELETE FROM tblGroup WHERE GroupID = " + tempID;
            if(connData.ExecuteQuery(sql))
            {
                MessageBox.Show("Xóa nhóm thành công", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }
            return false;
        }
        //ValidateGroup
        public bool ValidateGroup(Group g) 
        {
            if(g.GroupName.Equals(""))
            {
                MessageBox.Show("Tên nhóm không được để trống","Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return false;
            }
            if (g.GroupName.Equals("Undefined")) 
            {
                MessageBox.Show("Không thể đặt tên nhóm trùng với nhóm mặc định", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if(g.Department.Equals(""))
            {
                MessageBox.Show("Tên bộ phận không được để trống", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            
            return true;
        }
        public string NextID()
        {
            return Utilitiescs.NextID(connData.GetLastID("tblGroup","GroupID"));
        }
    }
}
