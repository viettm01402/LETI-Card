﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Management;
using System.Net.Sockets;
using System.Threading;
using FUTAS.DataAccess;

namespace FUTAS.BusinessLogic
{
    class ReadcardBUS
    {
        System.Net.Sockets.TcpClient clientSocket = new System.Net.Sockets.TcpClient();
        ConnectData conndata = new ConnectData();

        private EmployeeBUS empBUS = new EmployeeBUS();
        public void loadEmp()
        {
            string sql = "SELECT CardID, EmpName FROM tblEmployee";
            conndata.ExecuteQuery(sql);
        }
        public void deleteData()
        {
            string sql = "DELETE FROM tblTempRecord";
            conndata.ExecuteQuery(sql);
        }
        public void updateData()
        {
            string sql = "INSERT INTO tblRecord (CardID,EmpID,RecordTime) SELECT CardID,EmpID,RecordTime FROM tblTempRecord";
            conndata.ExecuteQuery(sql);
        }
        public void addInfoCard()
        {
            string sourcePath = Application.StartupPath;
            int flag = 0;
            if (empBUS.GetListEmployee().Rows.Count != 0)
            {
                foreach (DataRow dr in empBUS.GetListEmployee().Rows)
                {
                    if (dr["CardID"].ToString().Equals(fmMain.ID))
                    {
                        flag = 1;
                        string sql = "INSERT INTO tbltempRecord (cardID, EmpID, RecordTime) VALUES('" + dr["CardID"].ToString() + "','" + dr["EmpID"].ToString() + "','" + DateTime.Now.ToString() + "')";
                        conndata.ExecuteQuery(sql);
                    }

                }
            }
            if (flag == 0)
            {
                DialogResult dialogResult = MessageBox.Show("This is new Card ID.\n Do you want to add to database?", "Add new card", MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    //do something
                    fmEmployee fme = new fmEmployee();
                    fme.Show();
                }
                else if (dialogResult == DialogResult.No)
                {
                    //do something else
                }
            }
        }

    }
}

