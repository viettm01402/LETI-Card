﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

using FUTAS.BusinessLogic;
using FUTAS.BusinessObject;

namespace FUTAS
{
    public partial class fmShift : Form
    {
        private ShiftBUS shiftBUS = new ShiftBUS();
        public fmShift()
        {
            InitializeComponent();
        }

        private void fmShift_Load(object sender, EventArgs e)
        {
            //Load dataGridview
            dataGridViewShift.DataSource = shiftBUS.getShift();
            EnableEditing(false);
        }
        //binding data
        private void dataGridViewShift_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            //dong hien tai
            int row = e.RowIndex;
            //binding data len control, khi click vao row trong dataGridview
            tBShiftCode.Text = dataGridViewShift.Rows[row].Cells["ShiftID"].Value.ToString();
            tBShiftName.Text = dataGridViewShift.Rows[row].Cells["ShiftName"].Value.ToString();
            tBShiftStartTime.Text = dataGridViewShift.Rows[row].Cells["StartTime"].Value.ToString();
            tBShiftEndTime.Text = dataGridViewShift.Rows[row].Cells["EndTime"].Value.ToString();
            tBShiftType.Text = dataGridViewShift.Rows[row].Cells["ShiftType"].Value.ToString();
            tBShiftDesc.Text = dataGridViewShift.Rows[row].Cells["ShiftDescription"].Value.ToString();
            tBShiftRate.Text = dataGridViewShift.Rows[row].Cells["Rate"].Value.ToString();
        }
        //Disable edit, del btn
        private void EnableEditing(bool editing)
        {
            //button
            btnAdd.Enabled = !editing;
            btnEdit.Enabled = !editing;
            btnDel.Enabled = !editing;
            btnSave.Enabled = editing;
            btnCancel.Enabled = editing;
            //textbox
            tBShiftName.Enabled = editing;
            tBShiftStartTime.Enabled = editing;
            tBShiftEndTime.Enabled = editing;
            tBShiftType.Enabled = editing;
            tBShiftDesc.Enabled = editing;
            tBShiftRate.Enabled = editing;
            //DataGridView
            dataGridViewShift.Enabled = !editing;
        }
        //Reset textbox
        private void ResetTextbox()
        {
            tBShiftName.Text = "";
            tBShiftStartTime.Text = "";
            tBShiftEndTime.Text = "";
            tBShiftType.Text = "";
            tBShiftDesc.Text = "";
            tBShiftRate.Text = "";
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
                EnableEditing(true);
                ResetTextbox();
                //Load nextID
                tBShiftCode.Text = shiftBUS.nextID().ToString();
                //mac dinh gio va rate
                tBShiftStartTime.Text = "08:00:00";
                tBShiftEndTime.Text = "18:00:00";
                tBShiftRate.Text = "0";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            EnableEditing(false);
        }//validate input date
        public bool validateInputRate()
        {
            string inputRate = tBShiftRate.Text;
            Regex regex = new Regex(@"^[-+]?[0-9]*\.?[0-9]+$");
            if(regex.IsMatch(inputRate) == false)
            {
                //MessageBox.Show("Chi nhap so thuc");
                return false;
            }
            return true;
        }
        //validate input time
        public bool validateInputSTime()
        {
            string StartTime = tBShiftStartTime.Text;
            TimeSpan s;
            TimeSpan.TryParse(StartTime, out s);

            if (s.ToString().Equals("00:00:00"))
            {
                //MessageBox.Show("Chi nhap thoi gian dang hh:mm:ss");
                return false;
            }
            return true;
        }
        public bool validateInputETime()
        {
            string EndTime = tBShiftEndTime.Text;
            TimeSpan e;
            TimeSpan.TryParse(EndTime, out e);

            if (e.ToString().Equals("00:00:00"))
            {
                //MessageBox.Show("Chi nhap thoi gian dang hh:mm:ss");
                return false;
            }
            return true;
        }
        //lay thong tin shift
        private Shift getShift()
        {
            Shift sh = new Shift();
            
                sh.ShiftID = Convert.ToInt32(tBShiftCode.Text);
                sh.ShiftName = tBShiftName.Text;

                if (validateInputSTime() == false)
                    tBShiftStartTime.Text = "00:00:01";
                string StartTime = tBShiftStartTime.Text;
                var sTime = TimeSpan.Parse(StartTime);
                sh.StartTime = Convert.ToDateTime(sTime.ToString());


                if (validateInputETime() == false)
                    tBShiftEndTime.Text = "00:00:01";
                string EndTime = tBShiftEndTime.Text;
                var eTime = TimeSpan.Parse(EndTime);
                sh.EndTime = Convert.ToDateTime(eTime.ToString());

                sh.ShiftType = tBShiftType.Text;
                sh.ShiftDescription = tBShiftDesc.Text;
                if (validateInputRate() == false)
                    tBShiftRate.Text = "0";
                sh.Rate = Convert.ToSingle(tBShiftRate.Text);
            return sh;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {

            //Call getShift
            Shift sh = getShift();
            //Ktra neu ton tai shiftID => edit
            if (shiftBUS.CheckExist(sh.ShiftID.ToString()))
            {
                if (shiftBUS.EditShift(sh))
                    fmShift_Load(sender, e);
            }
            else //add
            {
                if (shiftBUS.AddShift(sh))
                    fmShift_Load(sender, e);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (tBShiftCode.Text.Equals("1"))
            {
                MessageBox.Show("Không thể sửa được thông tin ca mặc định", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                EnableEditing(true);
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (tBShiftCode.Text.Equals("1"))
            {
                MessageBox.Show("Không thể xóa được thông tin ca mặc định", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (MessageBox.Show("Bạn có muốn xóa : " + tBShiftName.Text + " không", "Hỏi", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (shiftBUS.deleteShift(tBShiftCode.Text))
                        //load lai form shift
                        fmShift_Load(sender, e);
                }
            }
        }
    }
}
