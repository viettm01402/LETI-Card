﻿namespace FUTAS
{
    partial class fmOT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbOtID = new System.Windows.Forms.Label();
            this.txtOtID = new System.Windows.Forms.TextBox();
            this.lbOtName = new System.Windows.Forms.Label();
            this.txtOtName = new System.Windows.Forms.TextBox();
            this.lbOtRate = new System.Windows.Forms.Label();
            this.txtOtRate = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dtgOT = new System.Windows.Forms.DataGridView();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtStartTime = new System.Windows.Forms.TextBox();
            this.lbEndTime = new System.Windows.Forms.Label();
            this.lbStartTime = new System.Windows.Forms.Label();
            this.txtEndTime = new System.Windows.Forms.TextBox();
            this.OtID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtStartTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtEndTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtgOT)).BeginInit();
            this.SuspendLayout();
            // 
            // lbOtID
            // 
            this.lbOtID.AutoSize = true;
            this.lbOtID.Location = new System.Drawing.Point(15, 18);
            this.lbOtID.Name = "lbOtID";
            this.lbOtID.Size = new System.Drawing.Size(43, 13);
            this.lbOtID.TabIndex = 0;
            this.lbOtID.Text = "Mã OT:";
            // 
            // txtOtID
            // 
            this.txtOtID.Location = new System.Drawing.Point(63, 14);
            this.txtOtID.Name = "txtOtID";
            this.txtOtID.ReadOnly = true;
            this.txtOtID.Size = new System.Drawing.Size(100, 20);
            this.txtOtID.TabIndex = 1;
            // 
            // lbOtName
            // 
            this.lbOtName.AutoSize = true;
            this.lbOtName.Location = new System.Drawing.Point(15, 64);
            this.lbOtName.Name = "lbOtName";
            this.lbOtName.Size = new System.Drawing.Size(29, 13);
            this.lbOtName.TabIndex = 0;
            this.lbOtName.Text = "Tên:";
            // 
            // txtOtName
            // 
            this.txtOtName.Location = new System.Drawing.Point(63, 61);
            this.txtOtName.Name = "txtOtName";
            this.txtOtName.Size = new System.Drawing.Size(137, 20);
            this.txtOtName.TabIndex = 1;
            this.txtOtName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOtName_KeyPress);
            // 
            // lbOtRate
            // 
            this.lbOtRate.AutoSize = true;
            this.lbOtRate.Location = new System.Drawing.Point(451, 17);
            this.lbOtRate.Name = "lbOtRate";
            this.lbOtRate.Size = new System.Drawing.Size(38, 13);
            this.lbOtRate.TabIndex = 0;
            this.lbOtRate.Text = "Hệ số:";
            // 
            // txtOtRate
            // 
            this.txtOtRate.Location = new System.Drawing.Point(506, 14);
            this.txtOtRate.Name = "txtOtRate";
            this.txtOtRate.Size = new System.Drawing.Size(100, 20);
            this.txtOtRate.TabIndex = 1;
            this.txtOtRate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOtRate_KeyPress);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(18, 107);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(90, 38);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dtgOT
            // 
            this.dtgOT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgOT.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.OtID,
            this.OtName,
            this.OtStartTime,
            this.OtEndTime,
            this.OtRate});
            this.dtgOT.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dtgOT.Location = new System.Drawing.Point(0, 156);
            this.dtgOT.Name = "dtgOT";
            this.dtgOT.Size = new System.Drawing.Size(634, 199);
            this.dtgOT.TabIndex = 3;
            this.dtgOT.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgOT_RowEnter);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(145, 107);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(90, 38);
            this.btnUpdate.TabIndex = 2;
            this.btnUpdate.Text = "Sửa";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(278, 107);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(90, 38);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "&Xóa";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(399, 107);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 38);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "Lưu";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(516, 107);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(90, 38);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // txtStartTime
            // 
            this.txtStartTime.Location = new System.Drawing.Point(278, 14);
            this.txtStartTime.Name = "txtStartTime";
            this.txtStartTime.Size = new System.Drawing.Size(137, 20);
            this.txtStartTime.TabIndex = 5;
            // 
            // lbEndTime
            // 
            this.lbEndTime.AutoSize = true;
            this.lbEndTime.Location = new System.Drawing.Point(206, 64);
            this.lbEndTime.Name = "lbEndTime";
            this.lbEndTime.Size = new System.Drawing.Size(68, 13);
            this.lbEndTime.TabIndex = 4;
            this.lbEndTime.Text = "Giờ kết thúc:";
            // 
            // lbStartTime
            // 
            this.lbStartTime.AutoSize = true;
            this.lbStartTime.Location = new System.Drawing.Point(206, 17);
            this.lbStartTime.Name = "lbStartTime";
            this.lbStartTime.Size = new System.Drawing.Size(66, 13);
            this.lbStartTime.TabIndex = 6;
            this.lbStartTime.Text = "Giờ bắt đầu:";
            // 
            // txtEndTime
            // 
            this.txtEndTime.Location = new System.Drawing.Point(278, 61);
            this.txtEndTime.Name = "txtEndTime";
            this.txtEndTime.Size = new System.Drawing.Size(137, 20);
            this.txtEndTime.TabIndex = 7;
            // 
            // OtID
            // 
            this.OtID.DataPropertyName = "OtID";
            this.OtID.HeaderText = "Mã OT";
            this.OtID.Name = "OtID";
            this.OtID.ReadOnly = true;
            // 
            // OtName
            // 
            this.OtName.DataPropertyName = "OtName";
            this.OtName.HeaderText = "Tên";
            this.OtName.Name = "OtName";
            this.OtName.ReadOnly = true;
            // 
            // OtStartTime
            // 
            this.OtStartTime.DataPropertyName = "OtStartTime";
            this.OtStartTime.HeaderText = "Giờ bắt đầu";
            this.OtStartTime.Name = "OtStartTime";
            this.OtStartTime.ReadOnly = true;
            // 
            // OtEndTime
            // 
            this.OtEndTime.DataPropertyName = "OtEndTime";
            this.OtEndTime.HeaderText = "Giờ kết thúc";
            this.OtEndTime.Name = "OtEndTime";
            this.OtEndTime.ReadOnly = true;
            // 
            // OtRate
            // 
            this.OtRate.DataPropertyName = "OtRate";
            this.OtRate.HeaderText = "Hệ số";
            this.OtRate.Name = "OtRate";
            this.OtRate.ReadOnly = true;
            // 
            // fmOT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 355);
            this.Controls.Add(this.txtEndTime);
            this.Controls.Add(this.lbStartTime);
            this.Controls.Add(this.txtStartTime);
            this.Controls.Add(this.lbEndTime);
            this.Controls.Add(this.dtgOT);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtOtRate);
            this.Controls.Add(this.lbOtRate);
            this.Controls.Add(this.txtOtName);
            this.Controls.Add(this.lbOtName);
            this.Controls.Add(this.txtOtID);
            this.Controls.Add(this.lbOtID);
            this.MaximizeBox = false;
            this.Name = "fmOT";
            this.Text = "FUTAS - Quản lý OT";
            this.Load += new System.EventHandler(this.fmOT_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgOT)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbOtID;
        private System.Windows.Forms.TextBox txtOtID;
        private System.Windows.Forms.Label lbOtName;
        private System.Windows.Forms.TextBox txtOtName;
        private System.Windows.Forms.Label lbOtRate;
        private System.Windows.Forms.TextBox txtOtRate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dtgOT;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtID;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtName;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtStartTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtEndTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtRate;
        private System.Windows.Forms.TextBox txtStartTime;
        private System.Windows.Forms.Label lbEndTime;
        private System.Windows.Forms.Label lbStartTime;
        private System.Windows.Forms.TextBox txtEndTime;
    }
}