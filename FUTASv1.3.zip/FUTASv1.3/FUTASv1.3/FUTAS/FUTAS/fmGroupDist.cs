﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FUTAS.BusinessLogic;
using FUTAS.BusinessObject;

namespace FUTAS
{
    public partial class fmGroupDist : Form
    {
        private GrDistBUS grDistBUS = new GrDistBUS();
        private GroupBUS groupBUS = new GroupBUS();
        private ShiftBUS shiftBUS = new ShiftBUS();
        public fmGroupDist()
        {
            InitializeComponent();
        }

        private void fmGroupRecords_Load(object sender, EventArgs e)
        {
            //load combobox group
            cboGroupName.DataSource = groupBUS.GetAllGroup();
            cboGroupName.DisplayMember = "GroupName";
            cboGroupName.ValueMember = "GroupID";
            //load combobox shift
            cboShiftName.DataSource = shiftBUS.getShift();
            cboShiftName.DisplayMember = "ShiftName";
            cboShiftName.ValueMember = "ShiftID";
            //load combobox colGroupName
            colGroupName.DataSource = groupBUS.GetAllGroup();
            colGroupName.DisplayMember = "GroupName";
            colGroupName.ValueMember = "GroupID";
            //load combobox colShiftName
            colShiftName.DataSource = shiftBUS.getShift();
            colShiftName.DisplayMember = "ShiftName";
            colShiftName.ValueMember = "ShiftID";
            //load datagridview
            dataGridViewGrDist.DataSource = grDistBUS.getGrDist();
            EnableEditing(false);
        }
        //binding data
        private void dataGridViewGrDist_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            //dong hien tai
            int row = e.RowIndex;
            //binding data len control, khi click vao row trong dataGridview
            tBGRID.Text = dataGridViewGrDist.Rows[row].Cells["GRID"].Value.ToString();
            cboGroupName.SelectedValue = dataGridViewGrDist.Rows[row].Cells["colGroupName"].Value.ToString();
            cboShiftName.SelectedValue = dataGridViewGrDist.Rows[row].Cells["colShiftName"].Value.ToString();
        }
        //Disable edit, del btn
        private void EnableEditing(bool editing)
        {
            //button
            btnAdd.Enabled = !editing;
            btnEdit.Enabled = !editing;
            btnDel.Enabled = !editing;
            btnSave.Enabled = editing;
            btnCancel.Enabled = editing;
            //combobox
            cboGroupName.Enabled = editing;
            cboShiftName.Enabled = editing;
            //DataGridView
            dataGridViewGrDist.Enabled = !editing;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            EnableEditing(true);
            //Load nextID
            tBGRID.Text = grDistBUS.nextID().ToString();
        }
        private GroupDist getGroupDist()
        {
            GroupDist grd = new GroupDist();
            grd.GRID = Convert.ToInt32(grDistBUS.nextID());
            grd.GroupID = Convert.ToInt32(cboGroupName.SelectedValue.ToString());
            grd.ShiftID = Convert.ToInt32(cboShiftName.SelectedValue.ToString());
            return grd;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            GroupDist grd = getGroupDist();
            //Ktra neu ton tai GroupID => edit
            if (grDistBUS.CheckExist(grd.GroupID.ToString()))
            {
                if (grDistBUS.EditGroupDist(grd))
                    fmGroupRecords_Load(sender, e);
            }
            else //add
            {
                if (grDistBUS.AddGroupDist(grd))
                    fmGroupRecords_Load(sender, e);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            EnableEditing(false);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (tBGRID.Text.Equals("4"))
            {
                MessageBox.Show("Không thể sửa được thông tin nhóm mặc định", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                EnableEditing(true);
                cboGroupName.Enabled = false;
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (tBGRID.Text.Equals("4"))
            {
                MessageBox.Show("Không thể xóa được thông tin nhóm mặc định", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (MessageBox.Show("Ban co muon xoa phan ca cho : " + cboGroupName.Text + " khong?", "hoi", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (grDistBUS.deleteGroupDist(cboGroupName.SelectedValue.ToString()))
                        //load lai form shift
                        fmGroupRecords_Load(sender, e);
                }
            }
        }

    }
}
