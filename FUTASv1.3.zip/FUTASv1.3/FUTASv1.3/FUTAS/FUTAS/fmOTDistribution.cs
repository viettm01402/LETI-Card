﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FUTAS.DataAccess;
using FUTAS.BusinessLogic;
using FUTAS.BusinessObject;

namespace FUTAS
{
    public partial class fmOTDistribution : Form
    {
        private OTDisBUS odbus = new OTDisBUS();
        public fmOTDistribution()
        {
            InitializeComponent();
        }

        private void fmOTDistribution_Load(object sender, EventArgs e)
        {
            //Load comboboxOT type
            cboOTType.DataSource = odbus.GetAllOT();
            cboOTType.DisplayMember = "OtName";
            cboOTType.ValueMember = "OtID";
            //Load coboboxStatus
            cboOTStatus.DataSource = odbus.GetODStatus();
            cboOTStatus.DisplayMember = "NameOS";
            cboOTStatus.ValueMember = "OTStatus";
            //Load comboboxOT type
            cblOTType.DataSource = odbus.GetAllOT();
            cblOTType.DisplayMember = "OtName";
            cblOTType.ValueMember = "OtID";
            //Load coboboxStatus
            cblOTStatus.DataSource = odbus.GetODStatus();
            cblOTStatus.DisplayMember = "NameOS";
            cblOTStatus.ValueMember = "OTStatus";
            //Load datagridview
            dtgOTDistribution.DataSource = odbus.GetAllOD();
            EnableEditing(false);

        }
        private void EnableEditing(bool editing)
        {
            //Buttons
            btnAdd.Enabled = !editing;
            btnUpdate.Enabled = !editing;
            btnDel.Enabled = !editing;
            btnSave.Enabled = editing;
            btnCancel.Enabled = editing;
            btnAddOT.Enabled = editing;
            //Textbox
            
            txtEmpID.Enabled = editing;
            
                        dtpOTDate.Enabled = editing;
            cboOTStatus.Enabled = editing;
            cboOTType.Enabled = editing;
            //Datagridview
            dtgOTDistribution.Enabled = !editing;
        }
        private void btnAddOT_Click(object sender, EventArgs e)
        {
            fmOT fmot = new fmOT();
            fmot.Show();
            this.Close();

        }

        private void dtgOTDistribution_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            //dong hien tai
            int recentrow = e.RowIndex;

            //load data
            try
            {
                txtODID.Text = dtgOTDistribution.Rows[recentrow].Cells["ODID"].Value.ToString();
                txtEmpID.Text = dtgOTDistribution.Rows[recentrow].Cells["EmpID"].Value.ToString();
                cboOTType.SelectedValue = dtgOTDistribution.Rows[recentrow].Cells["cblOTType"].Value.ToString();
                cboOTStatus.SelectedValue = dtgOTDistribution.Rows[recentrow].Cells["cblOTStatus"].Value.ToString();
                dtpOTDate.Text = dtgOTDistribution.Rows[recentrow].Cells["OTDate"].Value.ToString();


            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi :"+ex.Message,"Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            fmOTDistribution_Load(sender, e);
        }
        private void ResetTextbox() 
        {
            txtEmpID.Text = "";
            
            dtpOTDate.Text = "";

        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            EnableEditing(true);
            ResetTextbox();
            txtODID.Text = odbus.NextID();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            EnableEditing(true);
        }
        private OTDistribution GetInPutData() 
        {
            OTDistribution otd = new OTDistribution();
            otd.ODID = int.Parse(txtODID.Text);
            otd.EmpID = int.Parse(txtEmpID.Text);
            otd.OTDate = Convert.ToDateTime(dtpOTDate.Value.ToShortDateString());
            otd.OtID = Convert.ToInt32(cboOTType.SelectedValue.ToString());
            otd.OTStatus = (cboOTStatus.SelectedValue.ToString() == "True") ? 1 : 0;
            return otd;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            OTDistribution otd = GetInPutData();
            if (odbus.CheckExistID(otd.ODID.ToString()))
            {
                if (odbus.UpdateOTD(otd))
                {
                    fmOTDistribution_Load(sender, e);
                }
            }
            else
            {
                if (odbus.checkexistOTD(otd))
                {
                    MessageBox.Show("Phân ca này đã tồn tại", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if (odbus.addOTD(otd))
                    {
                        fmOTDistribution_Load(sender, e);
                    }
                }
            }
        }

        private void txtEmpID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Chỉ được nhập số", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn muốn xóa phân ca này không?", "Xóa phân ca OT", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                odbus.DeleteOTD(txtODID.Text);
                fmOTDistribution_Load(sender, e);
            }
        }
    }
}
