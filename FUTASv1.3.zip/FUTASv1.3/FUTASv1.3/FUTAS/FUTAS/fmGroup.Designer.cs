﻿namespace FUTAS
{
    partial class fmGroup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDepart = new System.Windows.Forms.TextBox();
            this.lbGroupDepart = new System.Windows.Forms.Label();
            this.txtGroupName = new System.Windows.Forms.TextBox();
            this.lbGroupName = new System.Windows.Forms.Label();
            this.txtGroupID = new System.Windows.Forms.TextBox();
            this.lbGroupID = new System.Windows.Forms.Label();
            this.dtgGroup = new System.Windows.Forms.DataGridView();
            this.GroupID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GroupName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Department = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtgGroup)).BeginInit();
            this.SuspendLayout();
            // 
            // txtDepart
            // 
            this.txtDepart.Location = new System.Drawing.Point(459, 15);
            this.txtDepart.Name = "txtDepart";
            this.txtDepart.Size = new System.Drawing.Size(135, 20);
            this.txtDepart.TabIndex = 5;
            this.txtDepart.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDepart_KeyPress);
            // 
            // lbGroupDepart
            // 
            this.lbGroupDepart.AutoSize = true;
            this.lbGroupDepart.Location = new System.Drawing.Point(391, 18);
            this.lbGroupDepart.Name = "lbGroupDepart";
            this.lbGroupDepart.Size = new System.Drawing.Size(62, 13);
            this.lbGroupDepart.TabIndex = 3;
            this.lbGroupDepart.Text = "Phòng ban:";
            // 
            // txtGroupName
            // 
            this.txtGroupName.Location = new System.Drawing.Point(242, 14);
            this.txtGroupName.Name = "txtGroupName";
            this.txtGroupName.Size = new System.Drawing.Size(134, 20);
            this.txtGroupName.TabIndex = 7;
            this.txtGroupName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGroupName_KeyPress);
            // 
            // lbGroupName
            // 
            this.lbGroupName.AutoSize = true;
            this.lbGroupName.Location = new System.Drawing.Point(178, 18);
            this.lbGroupName.Name = "lbGroupName";
            this.lbGroupName.Size = new System.Drawing.Size(58, 13);
            this.lbGroupName.TabIndex = 2;
            this.lbGroupName.Text = "Tên nhóm:";
            // 
            // txtGroupID
            // 
            this.txtGroupID.Location = new System.Drawing.Point(72, 15);
            this.txtGroupID.Name = "txtGroupID";
            this.txtGroupID.ReadOnly = true;
            this.txtGroupID.Size = new System.Drawing.Size(90, 20);
            this.txtGroupID.TabIndex = 6;
            // 
            // lbGroupID
            // 
            this.lbGroupID.AutoSize = true;
            this.lbGroupID.Location = new System.Drawing.Point(12, 18);
            this.lbGroupID.Name = "lbGroupID";
            this.lbGroupID.Size = new System.Drawing.Size(54, 13);
            this.lbGroupID.TabIndex = 4;
            this.lbGroupID.Text = "Mã nhóm:";
            // 
            // dtgGroup
            // 
            this.dtgGroup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgGroup.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.GroupID,
            this.GroupName,
            this.Department});
            this.dtgGroup.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dtgGroup.Location = new System.Drawing.Point(0, 137);
            this.dtgGroup.Name = "dtgGroup";
            this.dtgGroup.Size = new System.Drawing.Size(615, 212);
            this.dtgGroup.TabIndex = 8;
            this.dtgGroup.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgGroup_RowEnter);
            // 
            // GroupID
            // 
            this.GroupID.DataPropertyName = "GroupID";
            this.GroupID.HeaderText = "Mã nhóm";
            this.GroupID.Name = "GroupID";
            this.GroupID.ReadOnly = true;
            // 
            // GroupName
            // 
            this.GroupName.DataPropertyName = "GroupName";
            this.GroupName.HeaderText = "Tên nhóm";
            this.GroupName.Name = "GroupName";
            this.GroupName.ReadOnly = true;
            // 
            // Department
            // 
            this.Department.DataPropertyName = "Department";
            this.Department.HeaderText = "Phòng ban";
            this.Department.Name = "Department";
            this.Department.ReadOnly = true;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(15, 68);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(90, 38);
            this.btnAdd.TabIndex = 9;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(137, 68);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(90, 38);
            this.btnUpdate.TabIndex = 9;
            this.btnUpdate.Text = "Sửa";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(259, 68);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(90, 38);
            this.btnDelete.TabIndex = 9;
            this.btnDelete.Text = "Xóa";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(381, 68);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 38);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Lưu";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(504, 68);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(90, 38);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Hủy";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // fmGroup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(615, 349);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dtgGroup);
            this.Controls.Add(this.txtDepart);
            this.Controls.Add(this.lbGroupDepart);
            this.Controls.Add(this.txtGroupName);
            this.Controls.Add(this.lbGroupName);
            this.Controls.Add(this.txtGroupID);
            this.Controls.Add(this.lbGroupID);
            this.MaximizeBox = false;
            this.Name = "fmGroup";
            this.Text = "FUTAS - Quản lý nhóm";
            this.Load += new System.EventHandler(this.fmGroup_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgGroup)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDepart;
        private System.Windows.Forms.Label lbGroupDepart;
        private System.Windows.Forms.TextBox txtGroupName;
        private System.Windows.Forms.Label lbGroupName;
        private System.Windows.Forms.TextBox txtGroupID;
        private System.Windows.Forms.Label lbGroupID;
        private System.Windows.Forms.DataGridView dtgGroup;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DataGridViewTextBoxColumn GroupID;
        private System.Windows.Forms.DataGridViewTextBoxColumn GroupName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Department;
    }
}